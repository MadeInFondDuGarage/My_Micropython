#ifndef _EPD_DRAW_
#define _EPD_DRW_H_

/******************************************************************************/
/***        include files                                                   ***/
/******************************************************************************/

#include "epd_driver.h"

#include <esp_assert.h>
#include <esp_heap_caps.h>
#include <esp_log.h>
#include <esp_types.h>

#include <string.h>


/******************************************************************************/
/***        macro definitions                                               ***/
/******************************************************************************/

#include "definition.h"

/******************************************************************************/
/***        type definitions                                                ***/
/******************************************************************************/

/** Display software rotation.
 *  Sets the rotation for the purposes of the drawing and font functions
 *  Use epd_set_rotation(EPD_ROT_*) to set it using one of the options below
 *  Use epd_get_rotation() in case you need to read this value
 */
enum Rotation {
    LANDSCAPE = 0,
    PORTRAIT = 1,
    INVERTED_LANDSCAPE = 2,
    INVERTED_PORTRAIT = 3,
};


/** Get the display rotation value */
enum Rotation epd_get_rotation();

/** Set the display rotation: Affects the drawing and font functions */
void epd_set_rotation(enum Rotation rotation);


/**
 * @brief Draw a picture to a given area. The image area is not cleared and
 *        assumed to be white before drawing.
 *
 * @param area The display area to draw to. `width` and `height` of the area
 *             must correspond to the image dimensions in pixels.
 * @param data The image data, as a buffer of 4 bit wide brightness values.
 *             Pixel data is packed (two pixels per byte). A byte cannot wrap
 *             over multiple rows, images of uneven width must add a padding
 *             nibble per line.
 */
void epd_print_grey_bitmap(Rect_t area, uint8_t *data);

/**
 * @brief Draw a pixel a given framebuffer.
 *
 * @param x           Horizontal position in pixels.
 * @param y           Vertical position in pixels.
 * @param color       The gray value of the line (0-255);
 * @param framebuffer The framebuffer to draw to.
 */
void epd_draw_pixel(int32_t x, int32_t y, uint8_t color, uint8_t *framebuffer);

/**
 * @brief Draw a picture to a given framebuffer.
 *
 * @param image_area  The area to copy to. `width` and `height` of the area must
 *                    correspond to the image dimensions in pixels.
 * @param image_data  The image data, as a buffer of 4 bit wide brightness values.
 *                    Pixel data is packed (two pixels per byte). A byte cannot
 *                    wrap over multiple rows, images of uneven width must add a
 *                    padding nibble per line.
 * @param framebuffer The framebuffer object, which must
 *                    be `EPD_WIDTH / 2 * EPD_HEIGHT` large.
 */
void epd_copy_to_framebuffer(Rect_t image_area, uint8_t *image_data,uint8_t *framebuffer);
                             

/**
 * @brief Draw a horizontal line to a given framebuffer.
 *
 * @param x           Horizontal start position in pixels.
 * @param y           Vertical start position in pixels.
 * @param length      Length of the line in pixels.
 * @param color       The gray value of the line (0-255);
 * @param framebuffer The framebuffer to draw to, which must
 *                    be `EPD_WIDTH / 2 * EPD_HEIGHT` bytes large.
 */
void epd_draw_hline(int32_t x, int32_t y, int32_t length, uint8_t color, uint8_t *framebuffer);

/**
 * @brief Draw a horizontal line to a given framebuffer.
 *
 * @param x           Horizontal start position in pixels.
 * @param y           Vertical start position in pixels.
 * @param length      Length of the line in pixels.
 * @param color       The gray value of the line (0-255);
 * @param framebuffer The framebuffer to draw to, which must
 *                    be `EPD_WIDTH / 2 * EPD_HEIGHT` bytes large.
 */
void epd_draw_vline(int32_t x, int32_t y, int32_t length, uint8_t color, uint8_t *framebuffer);

/**
 * @brief Draw a circle with given center and radius
 *
 * @param x0          Center-point x coordinate
 * @param y0          Center-point y coordinate
 * @param r           Radius of the circle in pixels
 * @param color       The gray value of the line (0-255);
 * @param framebuffer The framebuffer to draw to
 */
void epd_draw_circle(int32_t x, int32_t y, int32_t r, uint8_t color, uint8_t *framebuffer);

/**
 * @brief Draw a circle with fill with given center and radius
 *
 * @param x0          Center-point x coordinate
 * @param y0          Center-point y coordinate
 * @param r           Radius of the circle in pixels
 * @param color       The gray value of the line (0-255);
 * @param framebuffer The framebuffer to draw to,
 */
void epd_draw_fill_circle(int32_t x, int32_t y, int32_t r, uint8_t color, uint8_t *framebuffer);

/**
 * @brief Draw an oval with given center and radius
 *
 * @param x0          Center-point x coordinate
 * @param y0          Center-point y coordinate
 * @param rx          Radius of the circle in x plane
 * @param ry          Radius of the circle in y plane
 * @param color       The gray value of the line (0-255);
 * @param framebuffer The framebuffer to draw to
 */
void epd_draw_oval(int x0, int y0, int rx, int ry, uint8_t color, uint8_t *framebuffer);

/**
 * @brief Draw a rectanle with no fill color
 *
 * @param x           Top left corner x coordinate
 * @param y           Top left corner y coordinate
 * @param w           Width in pixels
 * @param h           Height in pixels
 * @param color       The gray value of the line (0-255);
 * @param framebuffer The framebuffer to draw to,
 */
void epd_draw_rect(int32_t x, int32_t y, int32_t w, int32_t h, uint8_t color, uint8_t *framebuffer);

/**
 * @brief Draw a rectanle with fill color
 *
 * @param x           Top left corner x coordinate
 * @param y           Top left corner y coordinate
 * @param w           Width in pixels
 * @param h           Height in pixels
 * @param color       The gray value of the line (0-255);
 * @param framebuffer The framebuffer to draw to
 */
void epd_draw_fill_rect(int32_t x, int32_t y, int32_t w, int32_t h, uint8_t color, uint8_t *framebuffer);

/**
 * @brief Write a line.  Bresenham's algorithm - thx wikpedia
 *
 * @param x0          Start point x coordinate
 * @param y0          Start point y coordinate
 * @param x1          End point x coordinate
 * @param y1          End point y coordinate
 * @param color       The gray value of the line (0-255);
 * @param framebuffer The framebuffer to draw to
 */
void epd_draw_write_line(int32_t x0, int32_t y0, int32_t x1, int32_t y1, uint8_t color, uint8_t *framebuffer);

/**
 * @brief Draw a line
 *
 * @param x0          Start point x coordinate
 * @param y0          Start point y coordinate
 * @param x1          End point x coordinate
 * @param y1          End point y coordinate
 * @param color       The gray value of the line (0-255);
 * @param framebuffer The framebuffer to draw to
 */
void epd_draw_line(int32_t x0, int32_t y0, int32_t x1, int32_t y1, uint8_t color, uint8_t *framebuffer);

/**
 * @brief Draw a triangle with no fill color
 *
 * @param x0          Vertex #0 x coordinate
 * @param y0          Vertex #0 y coordinate
 * @param x1          Vertex #1 x coordinate
 * @param y1          Vertex #1 y coordinate
 * @param x2          Vertex #2 x coordinate
 * @param y2          Vertex #2 y coordinate
 * @param color       The gray value of the line (0-255);
 * @param framebuffer The framebuffer to draw to
 */
void epd_draw_triangle(int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t x2, int32_t y2, uint8_t color, uint8_t *framebuffer);

/**
 * @brief Draw a triangle with color-fill
 *
 * @param x0          Vertex #0 x coordinate
 * @param y0          Vertex #0 y coordinate
 * @param x1          Vertex #1 x coordinate
 * @param y1          Vertex #1 y coordinate
 * @param x2          Vertex #2 x coordinate
 * @param y2          Vertex #2 y coordinate
 * @param color       The gray value of the line (0-255);
 * @param framebuffer The framebuffer to draw to
 */
void epd_draw_fill_triangle(int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t x2, int32_t y2, uint8_t color, uint8_t *framebuffer);

#endif
/******************************************************************************/
/***        END OF FILE                                                     ***/
/******************************************************************************/
