/******************************************************************************/
/***        include files                                                   ***/
/******************************************************************************/

#include "epd_draw.h"
#include <stdint.h>
#include <esp_assert.h>
#include <esp_heap_caps.h>
#include <esp_log.h>
#include <esp_types.h>
#include <math.h>

#include <string.h>

#include "epd_driver.h"


/******************************************************************************/
/***        macro definitions                                               ***/
/******************************************************************************/

#include "definition.h"

static enum Rotation display_rotation = LANDSCAPE;

// Simple x and y coordinate
typedef struct {
    uint16_t x;
    uint16_t y;
} Coord_xy;

#ifndef _swap_int
#define _swap_int(a, b) \
    {                   \
        int32_t t = a;      \
        a = b;          \
        b = t;          \
    }
#endif


/******************************************************************************/
/***        type definitions                                                ***/
/******************************************************************************/


void IRAM_ATTR epd_print_grey_bitmap(Rect_t area, uint8_t *data) //ecrit directement une image sur la zone area prévue sans passage dans le buffer. le data étant l'image. un buffer externe
{
    epd_screen_print(area, data, BLACK_ON_WHITE); // ici on choisi en noir sur blanc.
}

Coord_xy rotate(uint16_t x, uint16_t y) {
    switch (display_rotation) {
        case LANDSCAPE:
            //y = EPD_HEIGHT - y - 1;
            break;
        case PORTRAIT:
            _swap_int(x, y);
            break;
        case INVERTED_LANDSCAPE:
            x = EPD_WIDTH - x - 1;
            y = EPD_HEIGHT - y - 1;
            break;
        case INVERTED_PORTRAIT:
            _swap_int(x, y);
            y = EPD_HEIGHT - y - 1;
            break;
    }
    Coord_xy coord = { x, y };
    return coord;
}

void epd_set_rotation(enum Rotation rotation) {
    display_rotation = rotation;
}

enum Rotation epd_get_rotation() {
    return display_rotation;
}

void epd_copy_to_framebuffer(Rect_t image_area, uint8_t *image_data, uint8_t *framebuffer)
{
    assert(image_data != NULL || framebuffer != NULL);

    for (uint32_t i = 0; i < image_area.width * image_area.height; i++)
    {
        uint32_t value_index = i;
        // for images of uneven width,
        // consume an additional nibble per row.
        if (image_area.width % 2)
        {
            value_index += i / image_area.width;
        }
        uint8_t val = (value_index % 2) ? (image_data[value_index / 2] & 0xF0) >> 4
                                        : image_data[value_index / 2] & 0x0F;

        int32_t xx = image_area.x + i % image_area.width;
        if (xx < 0 || xx >= EPD_WIDTH)
        {
            continue;
        }
        int32_t yy = image_area.y + i / image_area.width;
        if (yy < 0 || yy >= EPD_HEIGHT)
        {
            continue;
        }
        Coord_xy coord = rotate(xx, yy);
        int32_t xxx = coord.x;
        int32_t yyy = coord.y;
        uint8_t *buf_ptr = &framebuffer[yyy * EPD_WIDTH / 2 + xxx / 2];
        //if(epd_get_rotation()==PORTRAIT){ *buf_ptr = &framebuffer[yyy * EPD_HEIGHT / 2 + xxx / 2];}
        if (xxx % 2)
        {
            *buf_ptr = (*buf_ptr & 0x0F) | (val << 4);
        }
        else
        {
            *buf_ptr = (*buf_ptr & 0xF0) | val;
        }
    }

}

void epd_draw_pixel(int32_t x, int32_t y, uint8_t color, uint8_t *framebuffer)
{
    Coord_xy coord = rotate(x, y);
    x = coord.x;
    y = coord.y;
    
    if (x < 0 || x >= EPD_WIDTH)
    {
        return;
    }
    if (y < 0 || y >= EPD_HEIGHT)
    {
        return;
    }
    uint8_t *buf_ptr = &framebuffer[y * EPD_WIDTH / 2 + x / 2];
    if (x % 2)
    {
        *buf_ptr = (*buf_ptr & 0x0F) | (color & 0xF0);
    }
    else
    {
        *buf_ptr = (*buf_ptr & 0xF0) | (color >> 4);
    }
}

void epd_draw_hline(int32_t x, int32_t y, int32_t length, uint8_t color, uint8_t *framebuffer)
{
    for (int32_t i = 0; i < length; i++)
    {
        int32_t xx = x + i;
        epd_draw_pixel(xx, y, color, framebuffer);
    }
}

void epd_draw_vline(int32_t x, int32_t y, int32_t length, uint8_t color, uint8_t *framebuffer)
{
    for (int32_t i = 0; i < length; i++)
    {
        int32_t yy = y + i;
        epd_draw_pixel(x, yy, color, framebuffer);
    }
}

void epd_draw_circle(int32_t x0, int32_t y0, int32_t r, uint8_t color, uint8_t *framebuffer)
{
    int32_t f = 1 - r;
    int32_t ddF_x = 1;
    int32_t ddF_y = -2 * r;
    int32_t x = 0;
    int32_t y = r;

    epd_draw_pixel(x0, y0 + r, color, framebuffer);
    epd_draw_pixel(x0, y0 - r, color, framebuffer);
    epd_draw_pixel(x0 + r, y0, color, framebuffer);
    epd_draw_pixel(x0 - r, y0, color, framebuffer);

    while (x < y)
    {
        if (f >= 0)
        {
            y--;
            ddF_y += 2;
            f += ddF_y;
        }
        x++;
        ddF_x += 2;
        f += ddF_x;

        epd_draw_pixel(x0 + x, y0 + y, color, framebuffer);
        epd_draw_pixel(x0 - x, y0 + y, color, framebuffer);
        epd_draw_pixel(x0 + x, y0 - y, color, framebuffer);
        epd_draw_pixel(x0 - x, y0 - y, color, framebuffer);
        epd_draw_pixel(x0 + y, y0 + x, color, framebuffer);
        epd_draw_pixel(x0 - y, y0 + x, color, framebuffer);
        epd_draw_pixel(x0 + y, y0 - x, color, framebuffer);
        epd_draw_pixel(x0 - y, y0 - x, color, framebuffer);
    }
}


static void epd_draw_fill_circle_helper(int32_t x0, int32_t y0, int32_t r, int32_t corners, int32_t delta,uint8_t color, uint8_t *framebuffer)
{
    int32_t f = 1 - r;
    int32_t ddF_x = 1;
    int32_t ddF_y = -2 * r;
    int32_t x = 0;
    int32_t y = r;
    int32_t px = x;
    int32_t py = y;

    delta++; // Avoid some +1's in the loop

    while (x < y)
    {
        if (f >= 0)
        {
            y--;
            ddF_y += 2;
            f += ddF_y;
        }
        x++;
        ddF_x += 2;
        f += ddF_x;
        // These checks avoid double-drawing certain lines, important
        // for the SSD1306 library which has an INVERT drawing mode.
        if (x < (y + 1))
        {
            if (corners & 1)
                epd_draw_vline(x0 + x, y0 - y, 2 * y + delta, color, framebuffer);
            if (corners & 2)
                epd_draw_vline(x0 - x, y0 - y, 2 * y + delta, color, framebuffer);
        }
        if (y != py)
        {
            if (corners & 1)
                epd_draw_vline(x0 + py, y0 - px, 2 * px + delta, color, framebuffer);
            if (corners & 2)
                epd_draw_vline(x0 - py, y0 - px, 2 * px + delta, color, framebuffer);
            py = y;
        }
        px = x;
    }
}


void epd_draw_fill_circle(int32_t x0, int32_t y0, int32_t r, uint8_t color, uint8_t *framebuffer)
{
    epd_draw_vline(x0, y0 - r, 2 * r + 1, color, framebuffer);
    epd_draw_fill_circle_helper(x0, y0, r, 3, 0, color, framebuffer);
}

void epd_draw_oval(int x0, int y0, int rx, int ry, uint8_t color, uint8_t *framebuffer) 
{
    int x = 0;
    int y = ry;
    int64_t rxSq = (int64_t)rx * rx;
    int64_t rySq = (int64_t)ry * ry;
    int64_t twoRxSq = 2 * rxSq;
    int64_t twoRySq = 2 * rySq;
    int64_t px = 0;
    int64_t py = twoRxSq * y;

    // Region 1: Top and bottom edges
    int64_t p = round(rySq - (rxSq * ry) + (0.25 * rxSq));
    while (px < py) {
        epd_draw_pixel(x0 + x, y0 + y, color, framebuffer);
        epd_draw_pixel(x0 - x, y0 + y, color, framebuffer);
        epd_draw_pixel(x0 + x, y0 - y, color, framebuffer);
        epd_draw_pixel(x0 - x, y0 - y, color, framebuffer);

        x++;
        px += twoRySq;
        if (p < 0) {
            p += rySq + px;
        } else {
            y--;
            py -= twoRxSq;
            p += rySq + px - py;
        }
    }

    // Region 2: Left and right edges
    p = round(rySq * (x + 0.5) * (x + 0.5) + rxSq * (y - 1) * (y - 1) - rxSq * rySq);
    while (y >= 0) {
        epd_draw_pixel(x0 + x, y0 + y, color, framebuffer);
        epd_draw_pixel(x0 - x, y0 + y, color, framebuffer);
        epd_draw_pixel(x0 + x, y0 - y, color, framebuffer);
        epd_draw_pixel(x0 - x, y0 - y, color, framebuffer);

        y--;
        py -= twoRxSq;
        if (p > 0) {
            p += rxSq - py;
        } else {
            x++;
            px += twoRySq;
            p += rxSq - py + px;
        }
    }
}

void epd_draw_rect(int32_t x, int32_t y, int32_t w, int32_t h, uint8_t color, uint8_t *framebuffer)
{
    epd_draw_hline(x, y, w, color, framebuffer);
    epd_draw_hline(x, y + h - 1, w, color, framebuffer);
    epd_draw_vline(x, y, h, color, framebuffer);
    epd_draw_vline(x + w - 1, y, h, color, framebuffer);
}

void epd_draw_fill_rect(int32_t x, int32_t y, int32_t w, int32_t h, uint8_t color, uint8_t *framebuffer)
{
    for (int32_t i = x; i < x + w; i++)
    {
        epd_draw_vline(i, y, h, color, framebuffer);
    }
}

void epd_draw_write_line(int32_t x0, int32_t y0, int32_t x1, int32_t y1, uint8_t color, uint8_t *framebuffer)
{
    int32_t steep = abs(y1 - y0) > abs(x1 - x0);
    if (steep)
    {
        _swap_int(x0, y0);
        _swap_int(x1, y1);
    }

    if (x0 > x1)
    {
        _swap_int(x0, x1);
        _swap_int(y0, y1);
    }

    int32_t dx, dy;
    dx = x1 - x0;
    dy = abs(y1 - y0);

    int32_t err = dx / 2;
    int32_t ystep;

    if (y0 < y1)
    {
        ystep = 1;
    }
    else
    {
        ystep = -1;
    }

    for (; x0 <= x1; x0++)
    {
        if (steep)
        {
            epd_draw_pixel(y0, x0, color, framebuffer);
        }
        else
        {
            epd_draw_pixel(x0, y0, color, framebuffer);
        }
        err -= dy;
        if (err < 0)
        {
            y0 += ystep;
            err += dx;
        }
    }
}

void epd_draw_line(int32_t x0, int32_t y0, int32_t x1, int32_t y1, uint8_t color, uint8_t *framebuffer)
{
    // Update in subclasses if desired!
    if (x0 == x1)
    {
        if (y0 > y1)
            _swap_int(y0, y1);
        epd_draw_vline(x0, y0, y1 - y0 + 1, color, framebuffer);
    }
    else if (y0 == y1)
    {
        if (x0 > x1)
            _swap_int(x0, x1);
        epd_draw_hline(x0, y0, x1 - x0 + 1, color, framebuffer);
    }
    else
    {
        epd_draw_write_line(x0, y0, x1, y1, color, framebuffer);
    }
}

void epd_draw_triangle(int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t x2, int32_t y2, uint8_t color, uint8_t *framebuffer)
{
    epd_draw_line(x0, y0, x1, y1, color, framebuffer);
    epd_draw_line(x1, y1, x2, y2, color, framebuffer);
    epd_draw_line(x2, y2, x0, y0, color, framebuffer);
}

void epd_draw_fill_triangle(int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t x2, int32_t y2,uint8_t color, uint8_t *framebuffer)
{
    int32_t a, b, y, last;

    // Sort coordinates by Y order (y2 >= y1 >= y0)
    if (y0 > y1)
    {
        _swap_int(y0, y1);
        _swap_int(x0, x1);
    }
    if (y1 > y2)
    {
        _swap_int(y2, y1);
        _swap_int(x2, x1);
    }
    if (y0 > y1)
    {
        _swap_int(y0, y1);
        _swap_int(x0, x1);
    }

    if (y0 == y2)
    { // Handle awkward all-on-same-line case as its own thing
        a = b = x0;
        if (x1 < a)
            a = x1;
        else if (x1 > b)
            b = x1;
        if (x2 < a)
            a = x2;
        else if (x2 > b)
            b = x2;
        epd_draw_hline(a, y0, b - a + 1, color, framebuffer);
        return;
    }

    int32_t dx01 = x1 - x0;
    int32_t dy01 = y1 - y0;
    int32_t dx02 = x2 - x0;
    int32_t dy02 = y2 - y0;
    int32_t dx12 = x2 - x1;
    int32_t dy12 = y2 - y1;
    int32_t sa = 0;
    int32_t sb = 0;

    // For upper part of triangle, find scanline crossings for segments
    // 0-1 and 0-2.  If y1=y2 (flat-bottomed triangle), the scanline y1
    // is included here (and second loop will be skipped, avoiding a /0
    // error there), otherwise scanline y1 is skipped here and handled
    // in the second loop...which also avoids a /0 error here if y0=y1
    // (flat-topped triangle).
    if (y1 == y2)
        last = y1; // Include y1 scanline
    else
        last = y1 - 1; // Skip it

    for (y = y0; y <= last; y++)
    {
        a = x0 + sa / dy01;
        b = x0 + sb / dy02;
        sa += dx01;
        sb += dx02;
        /* longhand:
        a = x0 + (x1 - x0) * (y - y0) / (y1 - y0);
        b = x0 + (x2 - x0) * (y - y0) / (y2 - y0);
        */
        if (a > b)
            _swap_int(a, b);
        epd_draw_hline(a, y, b - a + 1, color, framebuffer);
    }

    // For lower part of triangle, find scanline crossings for segments
    // 0-2 and 1-2.  This loop is skipped if y1=y2.
    sa = (int32_t)dx12 * (y - y1);
    sb = (int32_t)dx02 * (y - y0);
    for (; y <= y2; y++)
    {
        a = x1 + sa / dy12;
        b = x0 + sb / dy02;
        sa += dx12;
        sb += dx02;
        /* longhand:
        a = x1 + (x2 - x1) * (y - y1) / (y2 - y1);
        b = x0 + (x2 - x0) * (y - y0) / (y2 - y0);
        */
        if (a > b)
            _swap_int(a, b);
        epd_draw_hline(a, y, b - a + 1, color, framebuffer);
    }
}
