//
// Based on https://github.com/russhughes/lilygo_t547
// Patched for ESP32-S3 + LilyGo-EPD47 driver (https://github.com/Xinyuan-LilyGO/LilyGo-EPD47/tree/esp32s3)
// - Removed epd_highlevel / epd_internals dependencies
// - Removed rotation support (fixed landscape)
// - Removed back_fb / difference_fb / dirty_lines / waveform / lut
// - Fixed mp_obj_type_t API for MicroPython >= 1.20
// - Fixed mp_raise_ValueError API for MicroPython >= 1.20
// - EpdRect -> Rect_t
// - epd_draw_rect / epd_fill_rect signature updated
// - epd_fullclear -> epd_clear
// - epd_hl_update_area -> epd_draw_grayscale_image
//

#include <string.h>
#include <math.h>
#include "py/runtime.h"
#include "py/objstr.h"

#include "mpfile.h"
#include "tjpgd.h"
#include "epd_driver.h"
#include "t547.h"

//
// Method Implementations
//
extern const mp_obj_type_t t547_type;


// init()
static mp_obj_t t547_init(size_t n_args, const mp_obj_t *args) {
    epd_init();
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_init_obj, 1, 2, t547_init);

// deinit()
static mp_obj_t t547_deinit(mp_obj_t self_in) {
    epd_poweroff_all();
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_1(t547_deinit_obj, t547_deinit);

// power(state)
static mp_obj_t t547_power(mp_obj_t self_in, mp_obj_t state) {
    if (mp_obj_is_true(state)) {
        epd_poweron();
    } else {
        epd_poweroff();
    }
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_2(t547_power_obj, t547_power);

// width() - fixed landscape
static mp_obj_t t547_width(mp_obj_t self_in) {
    return mp_obj_new_int(EPD_WIDTH);
}
static MP_DEFINE_CONST_FUN_OBJ_1(t547_width_obj, t547_width);

// height() - fixed landscape
static mp_obj_t t547_height(mp_obj_t self_in) {
    return mp_obj_new_int(EPD_HEIGHT);
}
static MP_DEFINE_CONST_FUN_OBJ_1(t547_height_obj, t547_height);

// push(time, color)
static mp_obj_t t547_push(size_t n_args, const mp_obj_t *args) {
    int time  = mp_obj_get_int(args[1]);
    int color = mp_obj_get_int(args[2]);
    epd_push_pixels(epd_full_screen(), time, color);
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_push_obj, 1, 3, t547_push);

// clear()
static mp_obj_t t547_clear(size_t n_args, const mp_obj_t *args) {
    epd_clear();
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_clear_obj, 1, 7, t547_clear);

// show([x, y, w, h])
// draw_mode parameter kept for API compatibility but ignored
// epd_draw_grayscale_image does not support partial modes
static mp_obj_t t547_show(size_t n_args, const mp_obj_t *args) {
    t547_obj_t *self = MP_OBJ_TO_PTR(args[0]);

    if (n_args > 1 && !mp_obj_is_integer(args[1])) {
        mp_raise_ValueError(MP_ERROR_TEXT("Invalid mode"));
    }

    Rect_t area = {0, 0, EPD_WIDTH, EPD_HEIGHT};
    if (n_args == 6) {
        area.x      = mp_obj_get_int(args[2]);
        area.y      = mp_obj_get_int(args[3]);
        area.width  = mp_obj_get_int(args[4]);
        area.height = mp_obj_get_int(args[5]);
    }

    epd_draw_grayscale_image(area, self->front_fb);
    return mp_obj_new_int(0);
}
static MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_show_obj, 1, 6, t547_show);

// pixel(x, y, color)
static mp_obj_t t547_pixel(size_t n_args, const mp_obj_t *args) {
    t547_obj_t *self = MP_OBJ_TO_PTR(args[0]);
    int x     = mp_obj_get_int(args[1]);
    int y     = mp_obj_get_int(args[2]);
    int color = mp_obj_get_int(args[3]);
    epd_draw_pixel(x, y, color, self->front_fb);
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_pixel_obj, 4, 4, t547_pixel);

// hline(x, y, length, color)
static mp_obj_t t547_hline(size_t n_args, const mp_obj_t *args) {
    t547_obj_t *self  = MP_OBJ_TO_PTR(args[0]);
    mp_int_t x        = mp_obj_get_int(args[1]);
    mp_int_t y        = mp_obj_get_int(args[2]);
    mp_int_t length   = mp_obj_get_int(args[3]);
    mp_int_t color    = mp_obj_get_int(args[4]);
    epd_draw_hline(x, y, length, color, self->front_fb);
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_hline_obj, 5, 5, t547_hline);

// vline(x, y, length, color)
static mp_obj_t t547_vline(size_t n_args, const mp_obj_t *args) {
    t547_obj_t *self  = MP_OBJ_TO_PTR(args[0]);
    mp_int_t x        = mp_obj_get_int(args[1]);
    mp_int_t y        = mp_obj_get_int(args[2]);
    mp_int_t length   = mp_obj_get_int(args[3]);
    mp_int_t color    = mp_obj_get_int(args[4]);
    epd_draw_vline(x, y, length, color, self->front_fb);
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_vline_obj, 5, 5, t547_vline);

// circle(x, y, radius, color)
static mp_obj_t t547_circle(size_t n_args, const mp_obj_t *args) {
    t547_obj_t *self  = MP_OBJ_TO_PTR(args[0]);
    mp_int_t x        = mp_obj_get_int(args[1]);
    mp_int_t y        = mp_obj_get_int(args[2]);
    mp_int_t radius   = mp_obj_get_int(args[3]);
    mp_int_t color    = mp_obj_get_int(args[4]);
    epd_draw_circle(x, y, radius, color, self->front_fb);
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_circle_obj, 5, 5, t547_circle);

// fill_circle(x, y, radius, color)
static mp_obj_t t547_fill_circle(size_t n_args, const mp_obj_t *args) {
    t547_obj_t *self  = MP_OBJ_TO_PTR(args[0]);
    mp_int_t x        = mp_obj_get_int(args[1]);
    mp_int_t y        = mp_obj_get_int(args[2]);
    mp_int_t radius   = mp_obj_get_int(args[3]);
    mp_int_t color    = mp_obj_get_int(args[4]);
    epd_fill_circle(x, y, radius, color, self->front_fb);
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_fill_circle_obj, 5, 5, t547_fill_circle);

// rect(x, y, w, h, color)
static mp_obj_t t547_rect(size_t n_args, const mp_obj_t *args) {
    t547_obj_t *self  = MP_OBJ_TO_PTR(args[0]);
    mp_int_t x        = mp_obj_get_int(args[1]);
    mp_int_t y        = mp_obj_get_int(args[2]);
    mp_int_t w        = mp_obj_get_int(args[3]);
    mp_int_t h        = mp_obj_get_int(args[4]);
    mp_int_t color    = mp_obj_get_int(args[5]);
    epd_draw_rect(x, y, w, h, color, self->front_fb);
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_rect_obj, 6, 6, t547_rect);

// fill_rect(x, y, w, h, color)
static mp_obj_t t547_fill_rect(size_t n_args, const mp_obj_t *args) {
    t547_obj_t *self  = MP_OBJ_TO_PTR(args[0]);
    mp_int_t x        = mp_obj_get_int(args[1]);
    mp_int_t y        = mp_obj_get_int(args[2]);
    mp_int_t w        = mp_obj_get_int(args[3]);
    mp_int_t h        = mp_obj_get_int(args[4]);
    mp_int_t color    = mp_obj_get_int(args[5]);
    epd_fill_rect(x, y, w, h, color, self->front_fb);
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_fill_rect_obj, 6, 6, t547_fill_rect);

// line(x0, y0, x1, y1, color)
static mp_obj_t t547_line(size_t n_args, const mp_obj_t *args) {
    t547_obj_t *self  = MP_OBJ_TO_PTR(args[0]);
    mp_int_t x0       = mp_obj_get_int(args[1]);
    mp_int_t y0       = mp_obj_get_int(args[2]);
    mp_int_t x1       = mp_obj_get_int(args[3]);
    mp_int_t y1       = mp_obj_get_int(args[4]);
    mp_int_t color    = mp_obj_get_int(args[5]);
    epd_draw_line(x0, y0, x1, y1, color, self->front_fb);
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_line_obj, 6, 6, t547_line);

// triangle(x0, y0, x1, y1, x2, y2, color)
static mp_obj_t t547_triangle(size_t n_args, const mp_obj_t *args) {
    t547_obj_t *self  = MP_OBJ_TO_PTR(args[0]);
    mp_int_t x0       = mp_obj_get_int(args[1]);
    mp_int_t y0       = mp_obj_get_int(args[2]);
    mp_int_t x1       = mp_obj_get_int(args[3]);
    mp_int_t y1       = mp_obj_get_int(args[4]);
    mp_int_t x2       = mp_obj_get_int(args[5]);
    mp_int_t y2       = mp_obj_get_int(args[6]);
    mp_int_t color    = mp_obj_get_int(args[7]);
    epd_draw_triangle(x0, y0, x1, y1, x2, y2, color, self->front_fb);
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_triangle_obj, 8, 8, t547_triangle);

// fill_triangle(x0, y0, x1, y1, x2, y2, color)
static mp_obj_t t547_fill_triangle(size_t n_args, const mp_obj_t *args) {
    t547_obj_t *self  = MP_OBJ_TO_PTR(args[0]);
    mp_int_t x0       = mp_obj_get_int(args[1]);
    mp_int_t y0       = mp_obj_get_int(args[2]);
    mp_int_t x1       = mp_obj_get_int(args[3]);
    mp_int_t y1       = mp_obj_get_int(args[4]);
    mp_int_t x2       = mp_obj_get_int(args[5]);
    mp_int_t y2       = mp_obj_get_int(args[6]);
    mp_int_t color    = mp_obj_get_int(args[7]);
    epd_fill_triangle(x0, y0, x1, y1, x2, y2, color, self->front_fb);
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_fill_triangle_obj, 8, 8, t547_fill_triangle);

// copy_bitmap(bitmap, x, y, width, height)
static mp_obj_t t547_copy_bitmap(size_t n_args, const mp_obj_t *args) {
    t547_obj_t *self = MP_OBJ_TO_PTR(args[0]);

    mp_buffer_info_t bitmap_info;
    mp_get_buffer_raise(args[1], &bitmap_info, MP_BUFFER_READ);

    Rect_t area = {
        .x      = mp_obj_get_int(args[2]),
        .y      = mp_obj_get_int(args[3]),
        .width  = mp_obj_get_int(args[4]),
        .height = mp_obj_get_int(args[5]),
    };

    epd_copy_to_framebuffer(area, bitmap_info.buf, self->front_fb);
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_copy_bitmap_obj, 6, 6, t547_copy_bitmap);

//
// Font rendering (bitmap fonts from russhughes font modules)
//

static uint32_t bs_bit = 0;
uint8_t *bitmap_data = NULL;

static uint8_t get_color(uint8_t bpp) {
    uint8_t color = 0;
    for (int i = 0; i < bpp; i++) {
        color <<= 1;
        color |= (bitmap_data[bs_bit / 8] & 1 << (7 - (bs_bit % 8))) > 0;
        bs_bit++;
    }
    return color;
}

// write_len(font, s)
static mp_obj_t t547_write_len(size_t n_args, const mp_obj_t *args) {
    mp_obj_module_t *font = MP_OBJ_TO_PTR(args[1]);
    mp_obj_dict_t *dict   = MP_OBJ_TO_PTR(font->globals);

    mp_obj_t widths_data_buff = mp_obj_dict_get(dict, MP_OBJ_NEW_QSTR(MP_QSTR_WIDTHS));
    mp_buffer_info_t widths_bufinfo;
    mp_get_buffer_raise(widths_data_buff, &widths_bufinfo, MP_BUFFER_READ);
    const uint8_t *widths_data = widths_bufinfo.buf;

    uint16_t print_width = 0;
    mp_obj_t map_obj = mp_obj_dict_get(dict, MP_OBJ_NEW_QSTR(MP_QSTR_MAP));
    GET_STR_DATA_LEN(map_obj, map_data, map_len);
    GET_STR_DATA_LEN(args[2], str_data, str_len);
    const byte *s = str_data, *top = str_data + str_len;

    while (s < top) {
        unichar ch = utf8_get_char(s);
        s = utf8_next_char(s);
        const byte *map_s = map_data, *map_top = map_data + map_len;
        uint16_t char_index = 0;
        while (map_s < map_top) {
            unichar map_ch = utf8_get_char(map_s);
            map_s = utf8_next_char(map_s);
            if (ch == map_ch) {
                print_width += widths_data[char_index];
                break;
            }
            char_index++;
        }
    }
    return mp_obj_new_int(print_width);
}
static MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_write_len_obj, 3, 3, t547_write_len);

// write(font, string, x, y [, fg, bg])
static mp_obj_t t547_write(size_t n_args, const mp_obj_t *args) {
    t547_obj_t *self      = MP_OBJ_TO_PTR(args[0]);
    mp_obj_module_t *font = MP_OBJ_TO_PTR(args[1]);
    mp_int_t x            = mp_obj_get_int(args[3]);
    mp_int_t y            = mp_obj_get_int(args[4]);
    mp_int_t fg_color     = (n_args > 5) ? mp_obj_get_int(args[5]) : 0;
    mp_int_t bg_color     = (n_args > 6) ? mp_obj_get_int(args[6]) : 0xf0;

    mp_obj_dict_t *dict = MP_OBJ_TO_PTR(font->globals);
    const uint8_t bpp          = mp_obj_get_int(mp_obj_dict_get(dict, MP_OBJ_NEW_QSTR(MP_QSTR_BPP)));
    const uint8_t height       = mp_obj_get_int(mp_obj_dict_get(dict, MP_OBJ_NEW_QSTR(MP_QSTR_HEIGHT)));
    const uint8_t offset_width = mp_obj_get_int(mp_obj_dict_get(dict, MP_OBJ_NEW_QSTR(MP_QSTR_OFFSET_WIDTH)));

    mp_buffer_info_t widths_bufinfo, offsets_bufinfo, bitmaps_bufinfo;
    mp_get_buffer_raise(mp_obj_dict_get(dict, MP_OBJ_NEW_QSTR(MP_QSTR_WIDTHS)),  &widths_bufinfo,  MP_BUFFER_READ);
    mp_get_buffer_raise(mp_obj_dict_get(dict, MP_OBJ_NEW_QSTR(MP_QSTR_OFFSETS)), &offsets_bufinfo, MP_BUFFER_READ);
    mp_get_buffer_raise(mp_obj_dict_get(dict, MP_OBJ_NEW_QSTR(MP_QSTR_BITMAPS)), &bitmaps_bufinfo, MP_BUFFER_READ);
    const uint8_t *widths_data  = widths_bufinfo.buf;
    const uint8_t *offsets_data = offsets_bufinfo.buf;
    bitmap_data                 = bitmaps_bufinfo.buf;

    mp_obj_t map_obj = mp_obj_dict_get(dict, MP_OBJ_NEW_QSTR(MP_QSTR_MAP));
    GET_STR_DATA_LEN(map_obj, map_data, map_len);
    GET_STR_DATA_LEN(args[2], str_data, str_len);
    const byte *s = str_data, *top = str_data + str_len;

    while (s < top) {
        unichar ch = utf8_get_char(s);
        s = utf8_next_char(s);
        const byte *map_s = map_data, *map_top = map_data + map_len;
        uint16_t char_index = 0;
        while (map_s < map_top) {
            unichar map_ch = utf8_get_char(map_s);
            map_s = utf8_next_char(map_s);
            if (ch == map_ch) {
                uint8_t width = widths_data[char_index];
                bs_bit = offsets_data[char_index * offset_width];
                if (offset_width > 1)
                    bs_bit = (bs_bit << 8) + offsets_data[char_index * offset_width + 1];
                if (offset_width > 2)
                    bs_bit = (bs_bit << 8) + offsets_data[char_index * offset_width + 2];
                for (uint16_t yy = 0; yy < height; yy++) {
                    for (uint16_t xx = 0; xx < width; xx++) {
                        if (get_color(bpp)) {
                            if (fg_color >= 0)
                                epd_draw_pixel(x + xx, y + yy, fg_color, self->front_fb);
                        } else {
                            if (bg_color >= 0)
                                epd_draw_pixel(x + xx, y + yy, bg_color, self->front_fb);
                        }
                    }
                }
                x += width;
                break;
            }
            char_index++;
        }
    }
    return mp_obj_new_int(x);
}
static MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_write_obj, 5, 9, t547_write);

// draw_len(font, s [, scale])
static mp_obj_t t547_draw_len(size_t n_args, const mp_obj_t *args) {
    char single_char_s[] = {0, 0};
    const char *s;
    mp_obj_module_t *hershey = MP_OBJ_TO_PTR(args[1]);

    if (mp_obj_is_int(args[2])) {
        single_char_s[0] = mp_obj_get_int(args[2]) & 0xff;
        s = single_char_s;
    } else {
        s = mp_obj_str_get_str(args[2]);
    }

    mp_float_t scale = 1.0;
    if (n_args > 3) {
        if (mp_obj_is_float(args[3]))     scale = mp_obj_float_get(args[3]);
        else if (mp_obj_is_int(args[3]))  scale = (mp_float_t) mp_obj_get_int(args[3]);
    }

    mp_obj_dict_t *dict = MP_OBJ_TO_PTR(hershey->globals);
    mp_buffer_info_t index_bufinfo, font_bufinfo;
    mp_get_buffer_raise(mp_obj_dict_get(dict, MP_OBJ_NEW_QSTR(MP_QSTR_INDEX)), &index_bufinfo, MP_BUFFER_READ);
    mp_get_buffer_raise(mp_obj_dict_get(dict, MP_OBJ_NEW_QSTR(MP_QSTR_FONT)),  &font_bufinfo,  MP_BUFFER_READ);
    uint8_t *index = index_bufinfo.buf;
    int8_t  *font  = font_bufinfo.buf;

    int16_t print_width = 0;
    char c;
    while ((c = *s++)) {
        if (c >= 32 && c <= 127) {
            int16_t ii     = (c - 32) * 2;
            int16_t offset = (index[ii] | (index[ii + 1] << 8)) + 1;
            int16_t left   = (int)(font[offset++] - 0x52);
            int16_t right  = (int)(font[offset++] - 0x52);
            print_width   += right - left;
        }
    }
    return mp_obj_new_int((int)(print_width * scale));
}
static MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_draw_len_obj, 3, 4, t547_draw_len);

// draw(font, string, x, y [, color, scale])
static mp_obj_t t547_draw(size_t n_args, const mp_obj_t *args) {
    t547_obj_t *self     = MP_OBJ_TO_PTR(args[0]);
    char single_char_s[] = {0, 0};
    const char *s;
    mp_obj_module_t *hershey = MP_OBJ_TO_PTR(args[1]);

    if (mp_obj_is_int(args[2])) {
        single_char_s[0] = mp_obj_get_int(args[2]) & 0xff;
        s = single_char_s;
    } else {
        s = mp_obj_str_get_str(args[2]);
    }

    mp_int_t x     = mp_obj_get_int(args[3]);
    mp_int_t y     = mp_obj_get_int(args[4]);
    mp_int_t color = (n_args > 5) ? mp_obj_get_int(args[5]) : 0x0;

    mp_float_t scale = 1.0;
    if (n_args > 6) {
        if (mp_obj_is_float(args[6]))     scale = mp_obj_float_get(args[6]);
        else if (mp_obj_is_int(args[6]))  scale = (mp_float_t) mp_obj_get_int(args[6]);
    }

    mp_obj_dict_t *dict = MP_OBJ_TO_PTR(hershey->globals);
    mp_buffer_info_t index_bufinfo, font_bufinfo;
    mp_get_buffer_raise(mp_obj_dict_get(dict, MP_OBJ_NEW_QSTR(MP_QSTR_INDEX)), &index_bufinfo, MP_BUFFER_READ);
    mp_get_buffer_raise(mp_obj_dict_get(dict, MP_OBJ_NEW_QSTR(MP_QSTR_FONT)),  &font_bufinfo,  MP_BUFFER_READ);
    uint8_t *index = index_bufinfo.buf;
    int8_t  *font  = font_bufinfo.buf;

    int16_t from_x = x, from_y = y, to_x = x, to_y = y, pos_x = x, pos_y = y;
    bool penup = true;
    char c;

    while ((c = *s++)) {
        if (c >= 32 && c <= 127) {
            int16_t ii     = (c - 32) * 2;
            int16_t offset = index[ii] | (index[ii + 1] << 8);
            int16_t length = font[offset++];
            int16_t left   = (int)(scale * (font[offset++] - 0x52) + 0.5);
            int16_t right  = (int)(scale * (font[offset++] - 0x52) + 0.5);
            int16_t width  = right - left;

            if (length) {
                for (int16_t i = 0; i < length; i++) {
                    if (font[offset] == ' ') {
                        offset += 2;
                        penup = true;
                        continue;
                    }
                    int16_t vx = (int)(scale * (font[offset++] - 0x52) + 0.5);
                    int16_t vy = (int)(scale * (font[offset++] - 0x52) + 0.5);
                    if (!i || penup) {
                        from_x = pos_x + vx - left;
                        from_y = pos_y + vy;
                    } else {
                        to_x = pos_x + vx - left;
                        to_y = pos_y + vy;
                        epd_draw_line(from_x, from_y, to_x, to_y, color, self->front_fb);
                        from_x = to_x;
                        from_y = to_y;
                    }
                    penup = false;
                }
            }
            pos_x += width;
        }
    }
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_draw_obj, 5, 7, t547_draw);

//
// JPG
//

#define JPG_MODE_FAST (0)
#define JPG_MODE_SLOW (1)

typedef struct {
    mp_file_t *fp;
    t547_obj_t *self;
} IODEV;

static unsigned int in_func(JDEC *jd, uint8_t *buff, unsigned int nbyte) {
    IODEV *dev = (IODEV *) jd->device;
    if (buff)
        return (unsigned int) mp_readinto(dev->fp, buff, nbyte);
    mp_seek(dev->fp, nbyte, SEEK_CUR);
    return nbyte;
}

static int out_fast(JDEC *jd, void *bitmap, JRECT *rect) {
    IODEV *dev  = (IODEV *) jd->device;
    uint8_t *src = bitmap;
    uint16_t idx = 0;
    for (uint16_t y = rect->top; y <= rect->bottom; y++)
        for (uint16_t x = rect->left; x <= rect->right; x++)
            epd_draw_pixel(jd->x_offs + x, jd->y_offs + y, src[idx++], dev->self->front_fb);
    return 1;
}

// jpg(filename, x, y [, mode])
static mp_obj_t t547_jpg(size_t n_args, const mp_obj_t *args) {
    t547_obj_t *self    = MP_OBJ_TO_PTR(args[0]);
    const char *filename = mp_obj_str_get_str(args[1]);
    mp_int_t x           = mp_obj_get_int(args[2]);
    mp_int_t y           = mp_obj_get_int(args[3]);

    JRESULT res;
    JDEC jdec;
    self->work = (void *) m_malloc(3800);
    IODEV devid;

    self->fp = mp_open(filename, "rb");
    devid.fp   = self->fp;
    devid.self = self;

    if (devid.fp) {
        res = jd_prepare(&jdec, in_func, self->work, 3800, &devid);
        if (res == JDR_OK) {
            jdec.x_offs = x;
            jdec.y_offs = y;
            res = jd_decomp(&jdec, out_fast, 0);
            if (res != JDR_OK)
                mp_raise_msg(&mp_type_RuntimeError, MP_ERROR_TEXT("jpg decompress failed."));
        } else {
            mp_raise_msg(&mp_type_RuntimeError, MP_ERROR_TEXT("jpg prepare failed."));
        }
        mp_close(devid.fp);
    }
    m_free(self->work);
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_jpg_obj, 4, 5, t547_jpg);

//
// Module
//

static const mp_rom_map_elem_t t547_locals_dict_table[] = {
    {MP_ROM_QSTR(MP_QSTR_init),          MP_ROM_PTR(&t547_init_obj)},
    {MP_ROM_QSTR(MP_QSTR_deinit),        MP_ROM_PTR(&t547_deinit_obj)},
    {MP_ROM_QSTR(MP_QSTR_power),         MP_ROM_PTR(&t547_power_obj)},
    {MP_ROM_QSTR(MP_QSTR_width),         MP_ROM_PTR(&t547_width_obj)},
    {MP_ROM_QSTR(MP_QSTR_height),        MP_ROM_PTR(&t547_height_obj)},
    {MP_ROM_QSTR(MP_QSTR_push),          MP_ROM_PTR(&t547_push_obj)},
    {MP_ROM_QSTR(MP_QSTR_clear),         MP_ROM_PTR(&t547_clear_obj)},
    {MP_ROM_QSTR(MP_QSTR_show),          MP_ROM_PTR(&t547_show_obj)},
    {MP_ROM_QSTR(MP_QSTR_pixel),         MP_ROM_PTR(&t547_pixel_obj)},
    {MP_ROM_QSTR(MP_QSTR_hline),         MP_ROM_PTR(&t547_hline_obj)},
    {MP_ROM_QSTR(MP_QSTR_vline),         MP_ROM_PTR(&t547_vline_obj)},
    {MP_ROM_QSTR(MP_QSTR_circle),        MP_ROM_PTR(&t547_circle_obj)},
    {MP_ROM_QSTR(MP_QSTR_fill_circle),   MP_ROM_PTR(&t547_fill_circle_obj)},
    {MP_ROM_QSTR(MP_QSTR_rect),          MP_ROM_PTR(&t547_rect_obj)},
    {MP_ROM_QSTR(MP_QSTR_fill_rect),     MP_ROM_PTR(&t547_fill_rect_obj)},
    {MP_ROM_QSTR(MP_QSTR_line),          MP_ROM_PTR(&t547_line_obj)},
    {MP_ROM_QSTR(MP_QSTR_triangle),      MP_ROM_PTR(&t547_triangle_obj)},
    {MP_ROM_QSTR(MP_QSTR_fill_triangle), MP_ROM_PTR(&t547_fill_triangle_obj)},
    {MP_ROM_QSTR(MP_QSTR_copy_bitmap),   MP_ROM_PTR(&t547_copy_bitmap_obj)},
    {MP_ROM_QSTR(MP_QSTR_write_len),     MP_ROM_PTR(&t547_write_len_obj)},
    {MP_ROM_QSTR(MP_QSTR_write),         MP_ROM_PTR(&t547_write_obj)},
    {MP_ROM_QSTR(MP_QSTR_draw_len),      MP_ROM_PTR(&t547_draw_len_obj)},
    {MP_ROM_QSTR(MP_QSTR_draw),          MP_ROM_PTR(&t547_draw_obj)},
    {MP_ROM_QSTR(MP_QSTR_jpg),           MP_ROM_PTR(&t547_jpg_obj)},

    {MP_ROM_QSTR(MP_QSTR_TRANSPARENT),   MP_ROM_INT(-1)},
    {MP_ROM_QSTR(MP_QSTR_FAST),          MP_ROM_INT(JPG_MODE_FAST)},
    {MP_ROM_QSTR(MP_QSTR_SLOW),          MP_ROM_INT(JPG_MODE_SLOW)},
};
static MP_DEFINE_CONST_DICT(t547_locals_dict, t547_locals_dict_table);

static void t547_print(const mp_print_t *print, mp_obj_t self_in, mp_print_kind_t kind) {
    (void) kind;
    mp_printf(print, "<t547>");
}

mp_obj_t t547_make_new(const mp_obj_type_t *type, size_t n_args, size_t n_kw, const mp_obj_t *all_args) {
    mp_arg_check_num(n_args, n_kw, 0, 0, false);

    const int fb_size = EPD_WIDTH / 2 * EPD_HEIGHT;
    t547_obj_t *self  = m_new_obj(t547_obj_t);
    self->base.type   = &t547_type;
    self->front_fb    = m_malloc(fb_size);

    if (self->front_fb == NULL)
        mp_raise_msg(&mp_type_MemoryError, MP_ERROR_TEXT("out of memory"));

    memset(self->front_fb, 0xFF, fb_size);
    return MP_OBJ_FROM_PTR(self);
}

MP_DEFINE_CONST_OBJ_TYPE(
    t547_type,
    MP_QSTR_t547,
    MP_TYPE_FLAG_NONE,
    print, t547_print,
    make_new, t547_make_new,
    locals_dict, &t547_locals_dict
);

static const mp_rom_map_elem_t t547_module_globals_table[] = {
    {MP_ROM_QSTR(MP_QSTR___name__), MP_ROM_QSTR(MP_QSTR_t547)},
    {MP_ROM_QSTR(MP_QSTR_T547),     (mp_obj_t) &t547_type},
};
static MP_DEFINE_CONST_DICT(t547_module_globals, t547_module_globals_table);

const mp_obj_module_t t547_user_cmodule = {
    .base    = {&mp_type_module},
    .globals = (mp_obj_dict_t *) &t547_module_globals,
};

MP_REGISTER_MODULE(MP_QSTR_t547, t547_user_cmodule);
