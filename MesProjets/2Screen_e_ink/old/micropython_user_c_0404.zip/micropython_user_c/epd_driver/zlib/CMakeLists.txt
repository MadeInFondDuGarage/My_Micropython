
idf_component_register(SRC_DIRS "."
                        INCLUDE_DIRS ".")
