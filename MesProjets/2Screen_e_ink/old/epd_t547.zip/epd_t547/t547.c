//
// Based on https://github.com/vroland/epdiy
// licensed under the  GNU LESSER GENERAL PUBLIC LICENSE Version 3
//

#include <string.h>
#include <math.h>
#include "py/runtime.h"
#include "py/objstr.h"

#include "mpfile.h"
#include "tjpgd.h"

#include "epd_driver.h"
#include "t547.h"
#include "epd_highlevel.h"

//
// Method Implementations
//

// @method init()
// @desc Initialize the ePaper display. This method must be called before any other method.

STATIC mp_obj_t t547_init(size_t n_args, const mp_obj_t *args) {
	t547_obj_t *self = MP_OBJ_TO_PTR(args[0]);

	epd_init(self, EPD_LUT_64K | EPD_FEED_QUEUE_32);
	epd_set_rotation(EPD_ROT_LANDSCAPE);

	return mp_const_none;
}
STATIC MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_init_obj, 1, 2, t547_init);

// @method deinit()
// @desc deinitialize the ePaper display

STATIC mp_obj_t t547_deinit(mp_obj_t self_in) {
	// t547_obj_t *self = MP_OBJ_TO_PTR(self_in);
	epd_deinit();
	return mp_const_none;
}
STATIC MP_DEFINE_CONST_FUN_OBJ_1(t547_deinit_obj, t547_deinit);

// @method power(state)
// @desc Enable or disable display power supply.
// @parm state(bool): True to enable power, False to disable.

STATIC mp_obj_t t547_power(mp_obj_t self_in, mp_obj_t state) {
	// t547_obj_t *self = MP_OBJ_TO_PTR(self_in);
	if (mp_obj_is_true(state)) {
		epd_poweron();
	} else {
		epd_poweroff();
	}

	return mp_const_none;
}
STATIC MP_DEFINE_CONST_FUN_OBJ_2(t547_power_obj, t547_power);

// @method rotation(state)
// @desc Set display rotation.
// @parm rotation(int): ROT_LANDSCAPE, ROT_PORTRAIT, INVERTED_LANDSCAPE, INVERTED_PORTRAIT

STATIC mp_obj_t t547_rotation(mp_obj_t self_in, mp_obj_t rotation_in) {
	// t547_obj_t *self = MP_OBJ_TO_PTR(self_in);
	int rotation = mp_obj_get_int(rotation_in);

	epd_set_rotation(rotation);

	return mp_const_none;
}
STATIC MP_DEFINE_CONST_FUN_OBJ_2(t547_rotation_obj, t547_rotation);

// @method width()
// @desc Return logical display width.
// @ret(int): logical display width

STATIC mp_obj_t t547_width(mp_obj_t self_in) {
	return mp_obj_new_int(epd_rotated_display_width());
}
STATIC MP_DEFINE_CONST_FUN_OBJ_1(t547_width_obj, t547_width);

// @method height()
// @desc Return logical display height.
// @ret(int): logical display height

STATIC mp_obj_t t547_height(mp_obj_t self_in) {
	return mp_obj_new_int(epd_rotated_display_height());
}
STATIC MP_DEFINE_CONST_FUN_OBJ_1(t547_height_obj, t547_height);

// @method push(color, time)
// @desc Push pixel of given color directly to the display
// @parm color: Color to push to the display
// @param time: pulse time in microseconds

STATIC mp_obj_t t547_push(size_t n_args, const mp_obj_t *args) {
	// t547_obj_t *self = MP_OBJ_TO_PTR(args[0]);
	int time = mp_obj_get_int(args[1]);
	int color = mp_obj_get_int(args[2]);

	epd_push_pixels(epd_full_screen(), time, color);

	return mp_const_none;
}
STATIC MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_push_obj, 1, 3, t547_push);

// @method clear()
// @desc Clear the entire screen.

STATIC mp_obj_t t547_clear(size_t n_args, const mp_obj_t *args) {
	t547_obj_t *self = MP_OBJ_TO_PTR(args[0]);
	epd_fullclear(self, self->temp);

	return mp_const_none;
}
STATIC MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_clear_obj, 1, 7, t547_clear);

// @method show({x, y, w, h})
// @desc Display framebuffer or area of the framebuffer on the screen.
// @param draw_mode: The draw mode to use. (default: MODE_GC16)
// @param x: X coordinate of the top left corner of the display area to show.
// @param y: Y coordinate of the top left corner of the display area to show.
// @param w: Width of the display area to show.
// @param h: Height of the display area to show.
//
// @info draw_mode: (default: MODE_GL16)
// @info   - MODE_GC16: Go from any grayscale value to another with a flashing update.
// @info   - MODE_GL16: Go from any grayscale value to another with a non-flashing update.
// @ret(int): EpdDrawError Code

STATIC mp_obj_t t547_show(size_t n_args, const mp_obj_t *args) {
	t547_obj_t *self = MP_OBJ_TO_PTR(args[0]);
	int draw_mode = MODE_GL16;
	if (n_args > 1) {
		if (mp_obj_is_integer(args[1])) {
			draw_mode = mp_obj_get_int(args[1]);
		} else {
			mp_raise_ValueError("Invalid mode");
		}
	}

	EpdRect area = {0, 0, EPD_WIDTH, EPD_HEIGHT};
	if (n_args == 6) {
		area.x = mp_obj_get_int(args[2]);
		area.y = mp_obj_get_int(args[3]);
		area.width = mp_obj_get_int(args[4]);
		area.height = mp_obj_get_int(args[5]);
	}

	return mp_obj_new_int(epd_hl_update_area(self, draw_mode, self->temp, area));
}
STATIC MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_show_obj, 1, 6, t547_show);

// @method pixel(x, y, color)
// @desc Draw a pixel in the framebuffer.
// @param x: Horizontal position in pixels.
// @param y: Vertical position in pixels.
// @param color: The gray value of the line (0-255);

STATIC mp_obj_t t547_pixel(size_t n_args, const mp_obj_t *args) {
	t547_obj_t *self = MP_OBJ_TO_PTR(args[0]);
	int x = mp_obj_get_int(args[1]);
	int y = mp_obj_get_int(args[2]);
	int color = mp_obj_get_int(args[3]);

	epd_draw_pixel(x, y, color, self->front_fb);

	return mp_const_none;
}
STATIC MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_pixel_obj, 4, 4, t547_pixel);


// @method hline(x, y, length, color)
// @desc Draw a horizontal line to the framebuffer.
// @param x(int): Horizontal start position in pixels.
// @param y(int): Vertical start position in pixels.
// @param length(int): Length of the line in pixels.
// @param color(int): The gray value of the line (0-255);
//
// void epd_draw_hline(int x, int y, int length, uint8_t color, uint8_t *framebuffer);

STATIC mp_obj_t t547_hline(size_t n_args, const mp_obj_t *args) {
	t547_obj_t *self = MP_OBJ_TO_PTR(args[0]);
	mp_int_t x = mp_obj_get_int(args[1]);
	mp_int_t y = mp_obj_get_int(args[2]);
	mp_int_t length = mp_obj_get_int(args[3]);
	mp_int_t color = mp_obj_get_int(args[4]);

	epd_draw_hline(x, y, length, color, self->front_fb);

	return mp_const_none;
}
STATIC MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_hline_obj, 5, 5, t547_hline);

// @method vline(x, y, length, color)
// @desc Draw a vertical line to the framebuffer.
//
// @param x(int): Horizontal start position in pixels.
// @param y(int): Vertical start position in pixels.
// @param length(int): Length of the line in pixels.
// @param color(int): The gray value of the line (0-255);
//
// void epd_draw_vline(int x, int y, int length, uint8_t color, uint8_t *framebuffer);

STATIC mp_obj_t t547_vline(size_t n_args, const mp_obj_t *args) {
	t547_obj_t *self = MP_OBJ_TO_PTR(args[0]);
	mp_int_t x = mp_obj_get_int(args[1]);
	mp_int_t y = mp_obj_get_int(args[2]);
	mp_int_t length = mp_obj_get_int(args[3]);
	mp_int_t color = mp_obj_get_int(args[4]);

	epd_draw_vline(x, y, length, color, self->front_fb);

	return mp_const_none;
}
STATIC MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_vline_obj, 5, 5, t547_vline);

// @method draw_circle(x, y, radius, color)
// @desc Draw a circle with given center and radius
// @param x(int): Center-point x coordinate
// @param y(int): Center-point y coordinate
// @param radius(int): Radius of the circle in pixels
// @param color(int): The gray value of the line (0-255);
//
// void epd_draw_circle(int x, int y, int r, uint8_t color, uint8_t *framebuffer);

STATIC mp_obj_t t547_circle(size_t n_args, const mp_obj_t *args) {
	t547_obj_t *self = MP_OBJ_TO_PTR(args[0]);
	mp_int_t x = mp_obj_get_int(args[1]);
	mp_int_t y = mp_obj_get_int(args[2]);
	mp_int_t radius = mp_obj_get_int(args[3]);
	mp_int_t color = mp_obj_get_int(args[4]);

	epd_draw_circle(x, y, radius, color, self->front_fb);

	return mp_const_none;
}
STATIC MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_circle_obj, 5, 5, t547_circle);

// @method fill_circle(x, y, radius, color )
// @desc Draw a circle with fill with given center and radius
// @param x: Center-point x coordinate
// @param y: Center-point y coordinate
// @param radius: Radius of the circle in pixels
// @param color: The gray value of the line (0-255);
//
// void epd_fill_circle(int x, int y, int r, uint8_t color, uint8_t *framebuffer);

STATIC mp_obj_t t547_fill_circle(size_t n_args, const mp_obj_t *args) {
	t547_obj_t *self = MP_OBJ_TO_PTR(args[0]);
	mp_int_t x = mp_obj_get_int(args[1]);
	mp_int_t y = mp_obj_get_int(args[2]);
	mp_int_t radius = mp_obj_get_int(args[3]);
	mp_int_t color = mp_obj_get_int(args[4]);

	epd_fill_circle(x, y, radius, color, self->front_fb);

	return mp_const_none;
}
STATIC MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_fill_circle_obj, 5, 5, t547_fill_circle);

// @method draw_rect(x, y, width, height, color)
// @desc Draw a rectanle with no fill color
// @param x(int): Top left corner x coordinate
// @param y(int): Top left corner y coordinate
// @param width(int): Width in pixels
// @param height(int): Height in pixels
// @param color(int): The gray value of the line (0-255);
//
// void epd_draw_rect(int x, int y, int w, int h, uint8_t color, uint8_t *framebuffer);

STATIC mp_obj_t t547_rect(size_t n_args, const mp_obj_t *args) {
	t547_obj_t *self = MP_OBJ_TO_PTR(args[0]);

	EpdRect area = {0, 0, EPD_WIDTH, EPD_HEIGHT};
	area.x = mp_obj_get_int(args[1]);
	area.y = mp_obj_get_int(args[2]);
	area.width = mp_obj_get_int(args[3]);
	area.height = mp_obj_get_int(args[4]);
	mp_int_t color = mp_obj_get_int(args[5]);

	epd_draw_rect(area, color, self->front_fb);

	return mp_const_none;
}
STATIC MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_rect_obj, 6, 6, t547_rect);

// @method fill_rect(x, y, width, height, color)
// @desc Draw a rectangle with fill color
// @param x(int): Top left corner x coordinate
// @param y(int): Top left corner y coordinate
// @param width(int): Width in pixels
// @param height(int): Height in pixels
// @param color(int): The gray value of the line (0-255);
//
// void epd_fill_rect(int x, int y, int w, int h, uint8_t color, uint8_t *framebuffer);

STATIC mp_obj_t t547_fill_rect(size_t n_args, const mp_obj_t *args) {
	t547_obj_t *self = MP_OBJ_TO_PTR(args[0]);

	EpdRect area = {0, 0, EPD_WIDTH, EPD_HEIGHT};
	area.x = mp_obj_get_int(args[1]);
	area.y = mp_obj_get_int(args[2]);
	area.width = mp_obj_get_int(args[3]);
	area.height = mp_obj_get_int(args[4]);
	mp_int_t color = mp_obj_get_int(args[5]);

	epd_fill_rect(area, color, self->front_fb);

	return mp_const_none;
}
STATIC MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_fill_rect_obj, 6, 6, t547_fill_rect);

// @line(x0, y0, x1, y1, color)
// @desc Draw a line from x0, y0 to x1, y1 with given color
// @param x0(int): Start point x coordinate
// @param y0(int): Start point y coordinate
// @param x1(int): End point x coordinate
// @param y1(int): End point y coordinate
// @param color(int): The gray value of the line (0-255);
//
// void epd_draw_line(int x0, int y0, int x1, int y1, uint8_t color, uint8_t *framebuffer);

STATIC mp_obj_t t547_line(size_t n_args, const mp_obj_t *args) {
	t547_obj_t *self = MP_OBJ_TO_PTR(args[0]);
	mp_int_t x0 = mp_obj_get_int(args[1]);
	mp_int_t y0 = mp_obj_get_int(args[2]);
	mp_int_t x1 = mp_obj_get_int(args[3]);
	mp_int_t y1 = mp_obj_get_int(args[4]);
	mp_int_t color = mp_obj_get_int(args[5]);

	epd_draw_line(x0, y0, x1, y1, color, self->front_fb);

	return mp_const_none;
}
STATIC MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_line_obj, 6, 6, t547_line);

// @method draw_triangle(x0, y0, x1, y1, x2, y3, color)
// @desc Draw a triangle with no fill color
// @param x0(int): Vertex #0 x coordinate
// @param y0(int): Vertex #0 y coordinate
// @param x1(int): Vertex #1 x coordinate
// @param y1(int): Vertex #1 y coordinate
// @param x2(int): Vertex #2 x coordinate
// @param y2(int): Vertex #2 y coordinate
// @param color: The grey value of the line (0-255);
//
// void epd_draw_triangle(int x0, int y0, int x1, int y1, int x2, int y2, uint8_t color, uint8_t *framebuffer);

STATIC mp_obj_t t547_triangle(size_t n_args, const mp_obj_t *args) {
	t547_obj_t *self = MP_OBJ_TO_PTR(args[0]);
	mp_int_t x0 = mp_obj_get_int(args[1]);
	mp_int_t y0 = mp_obj_get_int(args[2]);
	mp_int_t x1 = mp_obj_get_int(args[3]);
	mp_int_t y1 = mp_obj_get_int(args[4]);
	mp_int_t x2 = mp_obj_get_int(args[5]);
	mp_int_t y2 = mp_obj_get_int(args[6]);
	mp_int_t color = mp_obj_get_int(args[7]);

	epd_draw_triangle(x0, y0, x1, y1, x2, y2, color, self->front_fb);

	return mp_const_none;
}
STATIC MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_triangle_obj, 8, 8, t547_triangle);

// @method fill_triangle(x0, y0, x1, y1, x2, y3, color)
// @desc Draw a triangle with color fill
// @param x0(int): Vertex #0 x coordinate
// @param y0(int): Vertex #0 y coordinate
// @param x1(int): Vertex #1 x coordinate
// @param y1(int): Vertex #1 y coordinate
// @param x2(int): Vertex #2 x coordinate
// @param y2(int): Vertex #2 y coordinate
// @param color(int): The gray value of the line (0-255);
//
// void epd_fill_triangle(int x0, int y0, int x1, int y1, int x2, int y2, uint8_t color, uint8_t *framebuffer);

STATIC mp_obj_t t547_fill_triangle(size_t n_args, const mp_obj_t *args) {
	t547_obj_t *self = MP_OBJ_TO_PTR(args[0]);
	mp_int_t x0 = mp_obj_get_int(args[1]);
	mp_int_t y0 = mp_obj_get_int(args[2]);
	mp_int_t x1 = mp_obj_get_int(args[3]);
	mp_int_t y1 = mp_obj_get_int(args[4]);
	mp_int_t x2 = mp_obj_get_int(args[5]);
	mp_int_t y2 = mp_obj_get_int(args[6]);
	mp_int_t color = mp_obj_get_int(args[7]);

	epd_fill_triangle(x0, y0, x1, y1, x2, y2, color, self->front_fb);

	return mp_const_none;
}
STATIC MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_fill_triangle_obj, 8, 8, t547_fill_triangle);

// @method copy_bitmap(bitmnap, x, y, width, height)
// @desc Copy bitmap to the framebuffer at location x, y
// @param bitmap: bitmap data (4 bits per pixel, 2 pixels per byte)
// @param x(int): Top left corner x coordinate
// @param y(int): Top left corner y coordinate
// @param width(int): Width in pixels
// @param height(int): Height in pixels
//
// epd_copy_to_framebuffer(EpdRect image_area, const uint8_t *image_data, uint8_t *framebuffer) {

STATIC mp_obj_t t547_copy_bitmap(size_t n_args, const mp_obj_t *args) {
	t547_obj_t *self = MP_OBJ_TO_PTR(args[0]);

	mp_buffer_info_t bitmap_info;
	mp_get_buffer_raise(args[1], &bitmap_info, MP_BUFFER_READ);
	uint8_t *bitmap = bitmap_info.buf;

	EpdRect area = {0, 0, EPD_WIDTH, EPD_HEIGHT};
	area.x = mp_obj_get_int(args[2]);
	area.y = mp_obj_get_int(args[3]);
	area.width = mp_obj_get_int(args[4]);
	area.height = mp_obj_get_int(args[5]);

	epd_copy_to_framebuffer(area, bitmap, self->front_fb);

	return mp_const_none;
}
STATIC MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_copy_bitmap_obj, 6, 6, t547_copy_bitmap);

STATIC uint32_t bs_bit = 0;
uint8_t *bitmap_data = NULL;

STATIC uint8_t get_color(uint8_t bpp) {
	uint8_t color = 0;
	int i;

	for (i = 0; i < bpp; i++) {
		color <<= 1;
		color |= (bitmap_data[bs_bit / 8] & 1 << (7 - (bs_bit % 8))) > 0;
		bs_bit++;
	}
	return color;
}

// @method write_len(font, s)
// @desc Returns the pixel width of the string if written using the specified font.
// @param font(font_module): Font module to use
// @param s(string): String to use
// @ret (int): pixel width

STATIC mp_obj_t t547_write_len(size_t n_args, const mp_obj_t *args) {
	mp_obj_module_t *font = MP_OBJ_TO_PTR(args[1]);
	mp_obj_dict_t *dict = MP_OBJ_TO_PTR(font->globals);
	mp_obj_t widths_data_buff = mp_obj_dict_get(dict, MP_OBJ_NEW_QSTR(MP_QSTR_WIDTHS));
	mp_buffer_info_t widths_bufinfo;
	mp_get_buffer_raise(widths_data_buff, &widths_bufinfo, MP_BUFFER_READ);
	const uint8_t *widths_data = widths_bufinfo.buf;

	uint16_t print_width = 0;

	mp_obj_t map_obj = mp_obj_dict_get(dict, MP_OBJ_NEW_QSTR(MP_QSTR_MAP));
	GET_STR_DATA_LEN(map_obj, map_data, map_len);
	GET_STR_DATA_LEN(args[2], str_data, str_len);
	const byte *s = str_data, *top = str_data + str_len;

	while (s < top) {
		unichar ch;
		ch = utf8_get_char(s);
		s = utf8_next_char(s);

		const byte *map_s = map_data, *map_top = map_data + map_len;
		uint16_t char_index = 0;

		while (map_s < map_top) {
			unichar map_ch;
			map_ch = utf8_get_char(map_s);
			map_s = utf8_next_char(map_s);

			if (ch == map_ch) {
				print_width += widths_data[char_index];
				break;
			}
			char_index++;
		}
	}

	return mp_obj_new_int(print_width);
}
STATIC MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_write_len_obj, 3, 3, t547_write_len);


// @method write(font, string, x, y[, fg, bg])
// @desc Write string to framebuffer using a converted true-type font module starting at x, y,
// @ optionally using fg as foreground color and bg as background color. Transparancy for fg or bg
// @ can be specified by using TRANSPARENT.
// @param font(font_module): Font module to use
// @param string(string): String to write to framebuffer
// @param x(int): Column to start writing left edge of character.
// @param y(int): Row to start writing top edge of character.
// @param fg(optinal int): color to use as forground color, or TRANSPARENT
// @param bg(optinal int): color to use as background color, or TRANSPARENT

STATIC mp_obj_t t547_write(size_t n_args, const mp_obj_t *args) {
	t547_obj_t *self = MP_OBJ_TO_PTR(args[0]);
	mp_obj_module_t *font = MP_OBJ_TO_PTR(args[1]);

	mp_int_t x = mp_obj_get_int(args[3]);
	mp_int_t y = mp_obj_get_int(args[4]);
	mp_int_t fg_color;
	mp_int_t bg_color;

	fg_color = (n_args > 5) ? mp_obj_get_int(args[5]) : 0;
	bg_color = (n_args > 6) ? mp_obj_get_int(args[6]) : 0xf0;

	mp_obj_dict_t *dict = MP_OBJ_TO_PTR(font->globals);
	const uint8_t bpp = mp_obj_get_int(mp_obj_dict_get(dict, MP_OBJ_NEW_QSTR(MP_QSTR_BPP)));
	const uint8_t height = mp_obj_get_int(mp_obj_dict_get(dict, MP_OBJ_NEW_QSTR(MP_QSTR_HEIGHT)));
	const uint8_t offset_width = mp_obj_get_int(mp_obj_dict_get(dict, MP_OBJ_NEW_QSTR(MP_QSTR_OFFSET_WIDTH)));

	mp_obj_t widths_data_buff = mp_obj_dict_get(dict, MP_OBJ_NEW_QSTR(MP_QSTR_WIDTHS));
	mp_buffer_info_t widths_bufinfo;
	mp_get_buffer_raise(widths_data_buff, &widths_bufinfo, MP_BUFFER_READ);
	const uint8_t *widths_data = widths_bufinfo.buf;

	mp_obj_t offsets_data_buff = mp_obj_dict_get(dict, MP_OBJ_NEW_QSTR(MP_QSTR_OFFSETS));
	mp_buffer_info_t offsets_bufinfo;
	mp_get_buffer_raise(offsets_data_buff, &offsets_bufinfo, MP_BUFFER_READ);
	const uint8_t *offsets_data = offsets_bufinfo.buf;

	mp_obj_t bitmaps_data_buff = mp_obj_dict_get(dict, MP_OBJ_NEW_QSTR(MP_QSTR_BITMAPS));
	mp_buffer_info_t bitmaps_bufinfo;
	mp_get_buffer_raise(bitmaps_data_buff, &bitmaps_bufinfo, MP_BUFFER_READ);
	bitmap_data = bitmaps_bufinfo.buf;

	uint16_t print_width = 0;
	mp_obj_t map_obj = mp_obj_dict_get(dict, MP_OBJ_NEW_QSTR(MP_QSTR_MAP));
	GET_STR_DATA_LEN(map_obj, map_data, map_len);
	GET_STR_DATA_LEN(args[2], str_data, str_len);
	const byte *s = str_data, *top = str_data + str_len;
	while (s < top) {
		unichar ch;
		ch = utf8_get_char(s);
		s = utf8_next_char(s);

		const byte *map_s = map_data, *map_top = map_data + map_len;
		uint16_t char_index = 0;

		while (map_s < map_top) {
			unichar map_ch;
			map_ch = utf8_get_char(map_s);
			map_s = utf8_next_char(map_s);

			if (ch == map_ch) {
				uint8_t width = widths_data[char_index];
                bs_bit = offsets_data[char_index * offset_width];
                if (offset_width > 1)
                    bs_bit = (bs_bit << 8) + (offsets_data[char_index * offset_width + 1]);
                if (offset_width > 2)
                    bs_bit = (bs_bit << 8) + (offsets_data[char_index * offset_width + 2]);

				for (uint16_t yy = 0; yy < height; yy++) {
					for (uint16_t xx = 0; xx < width; xx++) {
						if (get_color(bpp)) {
							if (fg_color >= 0) {
								epd_draw_pixel(x + xx, y + yy, fg_color, self->front_fb);
							}
						} else {
							if (bg_color >= 0) {
								epd_draw_pixel(x + xx, y + yy, bg_color, self->front_fb);
							}
						}
					}
				}

				x += width;
				break;
			}
			char_index++;
		}
	}

	return mp_obj_new_int(print_width);
}
STATIC MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_write_obj, 5, 9, t547_write);

// @method draw_len(font, s)
// @desc Returns the pixel width of the string if written using the specified hershey font.
// @param font(hershey_module): Hershey font module to use
// @param s(string): String to draw
// @ret (int): pixel width

STATIC mp_obj_t t547_draw_len(size_t n_args, const mp_obj_t *args) {
	char single_char_s[] = {0, 0};
	const char *s;

	mp_obj_module_t *hershey = MP_OBJ_TO_PTR(args[1]);

	if (mp_obj_is_int(args[2])) {
		mp_int_t c = mp_obj_get_int(args[2]);
		single_char_s[0] = c & 0xff;
		s = single_char_s;
	} else {
		s = mp_obj_str_get_str(args[2]);
	}

	mp_float_t scale = 1.0;
	if (n_args > 3) {
		if (mp_obj_is_float(args[3])) {
			scale = mp_obj_float_get(args[3]);
		}
		if (mp_obj_is_int(args[3])) {
			scale = (mp_float_t) mp_obj_get_int(args[3]);
		}
	}

	mp_obj_dict_t *dict = MP_OBJ_TO_PTR(hershey->globals);
	mp_obj_t *index_data_buff = mp_obj_dict_get(dict, MP_OBJ_NEW_QSTR(MP_QSTR_INDEX));
	mp_buffer_info_t index_bufinfo;
	mp_get_buffer_raise(index_data_buff, &index_bufinfo, MP_BUFFER_READ);
	uint8_t *index = index_bufinfo.buf;

	mp_obj_t *font_data_buff = mp_obj_dict_get(dict, MP_OBJ_NEW_QSTR(MP_QSTR_FONT));
	mp_buffer_info_t font_bufinfo;
	mp_get_buffer_raise(font_data_buff, &font_bufinfo, MP_BUFFER_READ);
	int8_t *font = font_bufinfo.buf;

	int16_t print_width = 0;
	char c;
	int16_t ii;

	while ((c = *s++)) {
		if (c >= 32 && c <= 127) {
			ii = (c - 32) * 2;
			int16_t offset = (index[ii] | (index[ii + 1] << 8)) + 1;
			int16_t left = (int) (font[offset++] - 0x52);
			int16_t right = (int) (font[offset++] - 0x52);
			print_width += right - left;
		}
	}

	return mp_obj_new_int((int) (print_width * scale));
}
STATIC MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_draw_len_obj, 3, 4, t547_draw_len);

// @method draw(font, string, x, y[, fg])
// @desc Draw string to framebuffer using a Hershey font module starting at x, y,
// @ optionally using fg as foreground color.
// @param font(hershey_module): Hershey Font module to use
// @param string(string): String to draw to framebuffer
// @param x(int): Column to start writing left edge of character.
// @param y(int): Row to start writing bottom edge of character.
// @param fg(optinal int): color to use as forground color.

STATIC mp_obj_t t547_draw(size_t n_args, const mp_obj_t *args) {
	t547_obj_t *self = MP_OBJ_TO_PTR(args[0]);
	char single_char_s[] = {0, 0};
	const char *s;

	mp_obj_module_t *hershey = MP_OBJ_TO_PTR(args[1]);

	if (mp_obj_is_int(args[2])) {
		mp_int_t c = mp_obj_get_int(args[2]);
		single_char_s[0] = c & 0xff;
		s = single_char_s;
	} else {
		s = mp_obj_str_get_str(args[2]);
	}

	mp_int_t x = mp_obj_get_int(args[3]);
	mp_int_t y = mp_obj_get_int(args[4]);

	mp_int_t color = (n_args > 5) ? mp_obj_get_int(args[5]) : 0x0;

	mp_float_t scale = 1.0;
	if (n_args > 6) {
		if (mp_obj_is_float(args[6])) {
			scale = mp_obj_float_get(args[6]);
		}
		if (mp_obj_is_int(args[6])) {
			scale = (mp_float_t) mp_obj_get_int(args[6]);
		}
	}

	mp_obj_dict_t *dict = MP_OBJ_TO_PTR(hershey->globals);
	mp_obj_t *index_data_buff = mp_obj_dict_get(dict, MP_OBJ_NEW_QSTR(MP_QSTR_INDEX));
	mp_buffer_info_t index_bufinfo;
	mp_get_buffer_raise(index_data_buff, &index_bufinfo, MP_BUFFER_READ);
	uint8_t *index = index_bufinfo.buf;

	mp_obj_t *font_data_buff = mp_obj_dict_get(dict, MP_OBJ_NEW_QSTR(MP_QSTR_FONT));
	mp_buffer_info_t font_bufinfo;
	mp_get_buffer_raise(font_data_buff, &font_bufinfo, MP_BUFFER_READ);
	int8_t *font = font_bufinfo.buf;

	int16_t from_x = x;
	int16_t from_y = y;
	int16_t to_x = x;
	int16_t to_y = y;
	int16_t pos_x = x;
	int16_t pos_y = y;
	bool penup = true;
	char c;
	int16_t ii;

	while ((c = *s++)) {
		if (c >= 32 && c <= 127) {
			ii = (c - 32) * 2;

			int16_t offset = index[ii] | (index[ii + 1] << 8);
			int16_t length = font[offset++];
			int16_t left = (int) (scale * (font[offset++] - 0x52) + 0.5);
			int16_t right = (int) (scale * (font[offset++] - 0x52) + 0.5);
			int16_t width = right - left;

			if (length) {
				int16_t i;
				for (i = 0; i < length; i++) {
					if (font[offset] == ' ') {
						offset += 2;
						penup = true;
						continue;
					}

					int16_t vector_x = (int) (scale * (font[offset++] - 0x52) + 0.5);
					int16_t vector_y = (int) (scale * (font[offset++] - 0x52) + 0.5);

					if (!i || penup) {
						from_x = pos_x + vector_x - left;
						from_y = pos_y + vector_y;
					} else {
						to_x = pos_x + vector_x - left;
						to_y = pos_y + vector_y;

						epd_draw_line(from_x, from_y, to_x, to_y, color, self->front_fb);

						from_x = to_x;
						from_y = to_y;
					}
					penup = false;
				}
			}
			pos_x += width;
		}
	}

	return mp_const_none;
}
STATIC MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_draw_obj, 5, 7, t547_draw);

//
// jpg routines
//

#define JPG_MODE_FAST (0)
#define JPG_MODE_SLOW (1)

// User defined device identifier
typedef struct
{
	mp_file_t *fp;		 // File pointer for input function
	uint8_t *fbuf;		 // Pointer to the frame buffer for output function
	unsigned int wfbuf;	 // Width of the frame buffer [pix]
	unsigned int left;	 // jpg crop left column
	unsigned int top;	 // jpg crop top row
	unsigned int right;	 // jpg crop right column
	unsigned int bottom; // jpg crop bottom row

	t547_obj_t *self; // display object
} IODEV;

//
// file input function
//

static unsigned int in_func( // Returns number of bytes read (zero on error)
	JDEC *jd,				 // Decompression object
	uint8_t *buff,			 // Pointer to the read buffer (null to remove data)
	unsigned int nbyte)		 // Number of bytes to read/remove
{
	IODEV *dev = (IODEV *) jd->device; // Device identifier for the session (5th argument of jd_prepare function)
	unsigned int nread;

	if (buff) { // Read data from input stream
		nread = (unsigned int) mp_readinto(dev->fp, buff, nbyte);
		return nread;
	}

	// Remove data from input stream if buff was NULL
	mp_seek(dev->fp, nbyte, SEEK_CUR);
	return nbyte;
}

//
// fast output function
//

static int out_fast( // 1:Ok, 0:Aborted
	JDEC *jd,		 // Decompression object
	void *bitmap,	 // Bitmap data to be output
	JRECT *rect)	 // Rectangular region of output image
{
	IODEV *dev = (IODEV *) jd->device;
	uint8_t *src = bitmap;
	uint16_t x, y, idx = 0;

	uint16_t width = rect->right - rect->left + 1;
	uint16_t height = rect->bottom - rect->top + 1;

	if (0) {
		for (uint16_t by = 0; by < height; by++) {
			for (uint16_t bx = 0; bx < width; bx++) {
				int oldpixel = src[bx + by * width];
				int newpixel = oldpixel & 0xf0;
				int quant_error = oldpixel - newpixel;

				src[bx + by * width] = newpixel;
				src[bx + 1 + (width * (by))] = src[bx + 1 + (width * (by))] + quant_error * 7 / 16;
				src[bx - 1 + (width * (by + 1))] = src[bx - 1 + (width * (by + 1))] + quant_error * 3 / 16;
				src[bx + (width * (by + 1))] = src[bx + (width * (by + 1))] + quant_error * 5 / 16;
				src[bx + 1 + (width * (by + 1))] = src[bx + 1 + (width * (by + 1))] + quant_error * 1 / 16;
			}
		}
	}

	// Copy the decompressed 8bit greyscale rectanglar to the frame buffer
	src = (uint8_t *) bitmap;
	idx = 0;
	for (y = rect->top; y <= rect->bottom; y++) {
		for (x = rect->left; x <= rect->right; x++) {
			epd_draw_pixel(jd->x_offs + x, jd->y_offs + y, src[idx++], dev->self->front_fb);
		}
	}

	return 1; // Continue to decompress
}

//
// Slow output function: draw each
//

static int out_slow( // 1:Ok, 0:Aborted
	JDEC *jd,		 // Decompression object
	void *bitmap,	 // Bitmap data to be output
	JRECT *rect)	 // Rectangular region of output image
{
	IODEV *dev = (IODEV *) jd->device;

	uint8_t *src = bitmap;
	uint16_t y, x, idx = 0;

	// Copy the decompressed 8bit greyscale rectanglar to the frame buffer
	src = (uint8_t *) bitmap;
	for (y = rect->top; y <= rect->bottom; y++) {
		for (x = rect->left; x <= rect->right; x++) {
			epd_draw_pixel(jd->x_offs + x, jd->y_offs + y, src[idx++], dev->self->front_fb);
		}
	}

	return 1; // Continue to decompress
}

// @module jpg(filename, x ,y [, mode])
// @desc Draw jpg from a file at x, y using FAST mode or SLOW mode
// @param filename(ste): Filename of the jpg file
// @param x(int): Beginning column for the left edge of the jpg
// @param y(int): Beginning Row for the top eddge of the jpg
// @param mode(int): FAST or SLOW mode, FAST mode is the default and requires memory to be allocated
// @ equal to the uncompressed size of the jpg bitmap + 3800 bytes. The SLOW method will draw the
// @ image a piece at a time using the Minimum Coded Unit (MCU, typically a multiple of 8x8) of the
// @ image and requires memory to be allocated for the uncompressed bitmap size of the Minimum Coded
// @ Unit + 3800 bytes.


STATIC mp_obj_t t547_jpg(size_t n_args, const mp_obj_t *args) {
	t547_obj_t *self = MP_OBJ_TO_PTR(args[0]);

	const char *filename = mp_obj_str_get_str(args[1]);
	mp_int_t x = mp_obj_get_int(args[2]);
	mp_int_t y = mp_obj_get_int(args[3]);

	mp_int_t mode;

	if (n_args > 4)
		mode = mp_obj_get_int(args[4]);
	else
		mode = JPG_MODE_FAST;

	int (*outfunc)(JDEC *, void *, JRECT *);

	JRESULT res;						  // Result code of TJpgDec API
	JDEC jdec;							  // Decompression object
	self->work = (void *) m_malloc(3800); // Pointer to the work area
	IODEV devid;						  // User defined device identifier

	self->fp = mp_open(filename, "rb");
	devid.fp = self->fp;
	if (devid.fp) {
		// Prepare to decompress
		res = jd_prepare(&jdec, in_func, self->work, 3800, &devid);
		if (res == JDR_OK) {
			// Initialize output device
			if (mode == JPG_MODE_FAST) {
				outfunc = out_fast;
				jdec.x_offs = x;
				jdec.y_offs = y;
			} else {
				outfunc = out_slow;
				jdec.x_offs = x;
				jdec.y_offs = y;
			}

			devid.fbuf = (uint8_t *) self->front_fb;
			devid.wfbuf = jdec.width;
			devid.self = self;
			res = jd_decomp(&jdec, outfunc, 0); // Start to decompress with 1/1 scaling
			if (res != JDR_OK) {
				mp_raise_msg(&mp_type_RuntimeError, MP_ERROR_TEXT("jpg decompress failed."));
			}
		} else {
			mp_raise_msg(&mp_type_RuntimeError, MP_ERROR_TEXT("jpg prepare failed."));
		}
		mp_close(devid.fp);
	}
	m_free(self->work); // Discard work area
	return mp_const_none;
}

STATIC MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_jpg_obj, 4, 5, t547_jpg);

//
// Module Implementation
//

STATIC const mp_rom_map_elem_t t547_locals_dict_table[] = {
	{MP_ROM_QSTR(MP_QSTR_init), MP_ROM_PTR(&t547_init_obj)},
	{MP_ROM_QSTR(MP_QSTR_deinit), MP_ROM_PTR(&t547_deinit_obj)},
	{MP_ROM_QSTR(MP_QSTR_power), MP_ROM_PTR(&t547_power_obj)},
	{MP_ROM_QSTR(MP_QSTR_rotation), MP_ROM_PTR(&t547_rotation_obj)},
	{MP_ROM_QSTR(MP_QSTR_width), MP_ROM_PTR(&t547_width_obj)},
	{MP_ROM_QSTR(MP_QSTR_height), MP_ROM_PTR(&t547_height_obj)},
	{MP_ROM_QSTR(MP_QSTR_push), MP_ROM_PTR(&t547_push_obj)},
	{MP_ROM_QSTR(MP_QSTR_clear), MP_ROM_PTR(&t547_clear_obj)},
	{MP_ROM_QSTR(MP_QSTR_show), MP_ROM_PTR(&t547_show_obj)},
	{MP_ROM_QSTR(MP_QSTR_pixel), MP_ROM_PTR(&t547_pixel_obj)},
	{MP_ROM_QSTR(MP_QSTR_hline), MP_ROM_PTR(&t547_hline_obj)},
	{MP_ROM_QSTR(MP_QSTR_vline), MP_ROM_PTR(&t547_vline_obj)},
	{MP_ROM_QSTR(MP_QSTR_circle), MP_ROM_PTR(&t547_circle_obj)},
	{MP_ROM_QSTR(MP_QSTR_fill_circle), MP_ROM_PTR(&t547_fill_circle_obj)},
	{MP_ROM_QSTR(MP_QSTR_rect), MP_ROM_PTR(&t547_rect_obj)},
	{MP_ROM_QSTR(MP_QSTR_fill_rect), MP_ROM_PTR(&t547_fill_rect_obj)},
	{MP_ROM_QSTR(MP_QSTR_line), MP_ROM_PTR(&t547_line_obj)},
	{MP_ROM_QSTR(MP_QSTR_triangle), MP_ROM_PTR(&t547_triangle_obj)},
	{MP_ROM_QSTR(MP_QSTR_fill_triangle), MP_ROM_PTR(&t547_fill_triangle_obj)},
	{MP_ROM_QSTR(MP_QSTR_copy_bitmap), MP_ROM_PTR(&t547_copy_bitmap_obj)},
	{MP_ROM_QSTR(MP_QSTR_write_len), MP_ROM_PTR(&t547_write_len_obj)},
	{MP_ROM_QSTR(MP_QSTR_write), MP_ROM_PTR(&t547_write_obj)},
	{MP_ROM_QSTR(MP_QSTR_draw_len), MP_ROM_PTR(&t547_draw_len_obj)},
	{MP_ROM_QSTR(MP_QSTR_draw), MP_ROM_PTR(&t547_draw_obj)},
	{MP_ROM_QSTR(MP_QSTR_jpg), MP_ROM_PTR(&t547_jpg_obj)},

	{MP_ROM_QSTR(MP_QSTR_MODE_GC16), MP_ROM_INT(MODE_GC16)},
	{MP_ROM_QSTR(MP_QSTR_MODE_GL16), MP_ROM_INT(MODE_GL16)},

    {MP_ROM_QSTR(MP_QSTR_ROT_LANDSCAPE), MP_ROM_INT(EPD_ROT_LANDSCAPE)},
    {MP_ROM_QSTR(MP_QSTR_ROT_PORTRAIT), MP_ROM_INT(EPD_ROT_PORTRAIT)},
    {MP_ROM_QSTR(MP_QSTR_INVERTED_LANDSCAPE), MP_ROM_INT(EPD_ROT_INVERTED_LANDSCAPE)},
    {MP_ROM_QSTR(MP_QSTR_INVERTED_PORTRAIT), MP_ROM_INT(EPD_ROT_INVERTED_PORTRAIT)},

	{MP_ROM_QSTR(MP_QSTR_TRANSPARENT), MP_ROM_INT(-1)},

	{MP_ROM_QSTR(MP_QSTR_FAST), MP_ROM_INT(JPG_MODE_FAST)},
	{MP_ROM_QSTR(MP_QSTR_SLOW), MP_ROM_INT(JPG_MODE_SLOW)},

};

STATIC MP_DEFINE_CONST_DICT(t547_locals_dict, t547_locals_dict_table);

STATIC void t547_print(const mp_print_t *print, mp_obj_t self_in, mp_print_kind_t kind) {
	(void) kind;
	// t547_obj_t *self = MP_OBJ_TO_PTR(self_in);
	mp_printf(print, "<t547>");
}

const mp_obj_type_t t547_type = {
	{&mp_type_type},
	.name = MP_QSTR_t547,
	.print = t547_print,
	.make_new = t547_make_new,
	.locals_dict = (mp_obj_dict_t *) &t547_locals_dict,
};

mp_obj_t t547_make_new(const mp_obj_type_t *type, size_t n_args, size_t n_kw, const mp_obj_t *all_args) {
	enum {
		ARG_temp
	};

	static const mp_arg_t allowed_args[] = {
		{MP_QSTR_temp, MP_ARG_INT, {.u_int = 22}},
	};

	const static int fb_size = EPD_WIDTH / 2 * EPD_HEIGHT;

	mp_arg_val_t args[MP_ARRAY_SIZE(allowed_args)];
	mp_arg_parse_all_kw_array(n_args, n_kw, all_args, MP_ARRAY_SIZE(allowed_args), allowed_args, args);

	mp_arg_check_num(n_args, n_kw, 0, 0, false);
	t547_obj_t *self = m_new_obj(t547_obj_t);
	self->conversion_lut = NULL;
	self->base.type = &t547_type;

	self->back_fb = m_malloc(fb_size);
 	self->front_fb = m_malloc(fb_size);
	self->difference_fb = m_malloc(2 * fb_size);
  	self->dirty_lines = m_malloc(EPD_HEIGHT * sizeof(bool));
	self->lut_table = m_malloc(1 << 16);

	if (
		self->back_fb == NULL  		||
		self->front_fb == NULL  	||
		self->difference_fb == NULL ||
		self->dirty_lines == NULL  	||
		self->lut_table == NULL) {
		mp_raise_msg(&mp_type_MemoryError, MP_ERROR_TEXT("out of memory"));
	}

 	memset(self->front_fb, 0xFF, fb_size);
  	memset(self->back_fb, 0xFF, fb_size);
 	memset(self->difference_fb, 0xFF, fb_size * 2);
  	memset(self->dirty_lines, 0, EPD_HEIGHT * sizeof(bool));

    self->waveform = EPD_BUILTIN_WAVEFORM;
	self->temp = args[ARG_temp].u_int;

	return MP_OBJ_FROM_PTR(self);
}

STATIC const mp_rom_map_elem_t t547_module_globals_table[] = {
	{MP_ROM_QSTR(MP_QSTR___name__), MP_ROM_QSTR(MP_QSTR_t547)},
	{MP_ROM_QSTR(MP_QSTR_T547), (mp_obj_t) &t547_type},

};

STATIC MP_DEFINE_CONST_DICT(t547_module_globals, t547_module_globals_table);

const mp_obj_module_t t547_user_cmodule = {
	.base = {&mp_type_module},
	.globals = (mp_obj_dict_t *) &t547_module_globals,
};

MP_REGISTER_MODULE(MP_QSTR_t547, t547_user_cmodule);
