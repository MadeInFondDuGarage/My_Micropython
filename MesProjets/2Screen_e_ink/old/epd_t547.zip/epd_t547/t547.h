#ifndef T547_H
#define T547_H

#include <stdint.h>
#include <stdbool.h>

// Dépendances EPD (à adapter selon ton driver)
#include "epd_driver/epd_driver.h"


#include "epd_driver/epd_internals.h"
#include "mpfile.h"

typedef struct {
    uint8_t *front_fb;
    uint8_t *back_fb;
    uint8_t *difference_fb;
    bool *dirty_lines;
    uint8_t *lut_table;

    int temp;
} t547_t;

// Core
t547_t* t547_create(int temp);
void t547_destroy(t547_t *dev);

void t547_init(t547_t *dev);
void t547_deinit(void);

void t547_power_on(void);
void t547_power_off(void);

void t547_set_rotation(int rotation);

// Display info
int t547_width(void);
int t547_height(void);

// Drawing
void t547_clear(t547_t *dev);
void t547_pixel(t547_t *dev, int x, int y, uint8_t color);
void t547_hline(t547_t *dev, int x, int y, int length, uint8_t color);
void t547_vline(t547_t *dev, int x, int y, int length, uint8_t color);
void t547_line(t547_t *dev, int x0, int y0, int x1, int y1, uint8_t color);

void t547_rect(t547_t *dev, int x, int y, int w, int h, uint8_t color);
void t547_fill_rect(t547_t *dev, int x, int y, int w, int h, uint8_t color);

void t547_circle(t547_t *dev, int x, int y, int r, uint8_t color);
void t547_fill_circle(t547_t *dev, int x, int y, int r, uint8_t color);

// Update
int t547_show(t547_t *dev, int draw_mode, int x, int y, int w, int h);

#endif