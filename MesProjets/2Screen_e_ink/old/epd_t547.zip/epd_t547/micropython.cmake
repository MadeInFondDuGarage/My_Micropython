# Create an INTERFACE library for our C module.
add_library(usermod_T547 INTERFACE)

target_compile_definitions(usermod_T547 INTERFACE
    MODULE_T547_ENABLED=1
    MICROPY_PY_FILE_LIKE=1
)

# Add our source files to the lib
target_sources(usermod_T547 INTERFACE
    ${CMAKE_CURRENT_LIST_DIR}/t547.c
    ${CMAKE_CURRENT_LIST_DIR}/epd_highlevel.c
	${CMAKE_CURRENT_LIST_DIR}/epd_driver/epd_driver.c
    ${CMAKE_CURRENT_LIST_DIR}/epd_driver/render.c
    ${CMAKE_CURRENT_LIST_DIR}/epd_driver/display_ops.c
    ${CMAKE_CURRENT_LIST_DIR}/epd_driver/lut.c
	${CMAKE_CURRENT_LIST_DIR}/epd_driver/builtin_waveforms.c
    ${CMAKE_CURRENT_LIST_DIR}/epd_driver/i2s_data_bus.c
    ${CMAKE_CURRENT_LIST_DIR}/epd_driver/rmt_pulse.c
    ${CMAKE_CURRENT_LIST_DIR}/mpfile.c
    ${CMAKE_CURRENT_LIST_DIR}/tjpgd.c
)

# Add the current directory as an include directory.
target_include_directories(usermod_T547 INTERFACE
    ${CMAKE_CURRENT_LIST_DIR}
    ${CMAKE_CURRENT_LIST_DIR}/epd_driver
)


# Link our INTERFACE library to the usermod target.
target_link_libraries(usermod INTERFACE usermod_T547)
