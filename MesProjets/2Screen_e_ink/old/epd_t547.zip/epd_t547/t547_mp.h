#ifndef __t547_H__
#define __t547_H__

#include "epd_internals.h"
#include "py/runtime.h"
#include "py/objstr.h"
#include "mpfile.h"

typedef struct _t547_obj_t
{
    mp_obj_base_t base;             // module base class

    uint8_t *lut_table;             // conversion_lut table
    uint8_t* front_fb;              // The "front" framebuffer object.
    uint8_t* back_fb;               // The "back" framebuffer object.
    uint8_t* difference_fb;         // Buffer for holding the interlaced difference image.
    bool* dirty_lines;              // Tainted lines based on the last difference calculation.
    const EpdWaveform* waveform;    // The waveform information to use.
    uint8_t *conversion_lut;
    uint8_t temp;                   // screen tempature
    mp_file_t *fp;				    // file object for jpg
    void *work;                     // work buffer for jpg decoding

} t547_obj_t;

mp_obj_t t547_make_new(const mp_obj_type_t *type, size_t n_args, size_t n_kw, const mp_obj_t *args);

#endif
