/**
 * A high-level library for drawing to an EPD.
 */

#ifndef _EPD_DRIVER_H_
#define _EPD_DRIVER_H_

#ifdef __cplusplus
extern "C" {
#endif

/******************************************************************************/
/***        include files                                                   ***/
/******************************************************************************/

#include <esp_attr.h>

#include <stdbool.h>
#include <stdint.h>

/******************************************************************************/
/***        macro definitions                                               ***/
/******************************************************************************/

/**
 * @brief Width of the display area in pixels.
 */
#define EPD_WIDTH 960

/**
 * @brief Height of the display area in pixels.
 */
#define EPD_HEIGHT 540

/******************************************************************************/
/***        type definitions                                                ***/
/******************************************************************************/

/**
 * @brief An area on the display.
 */
typedef struct
{
    int32_t x;      /** Horizontal position. */
    int32_t y;      /** Vertical position. */
    int32_t width;  /** Area / image width, must be positive. */
    int32_t height; /** Area / image height, must be positive. */
} Rect_t;

/**
 * @brief The image drawing mode.
 */
typedef enum
{
    BLACK_ON_WHITE = 1 << 0, /** Draw black / grayscale image on a white display. */
    WHITE_ON_WHITE = 1 << 1, /** "Draw with white ink" on a white display. */
    WHITE_ON_BLACK = 1 << 2, /** Draw with white ink on a black display. */
} DrawMode_t;

/**
 * @brief Font drawing flags.
 */
enum DrawFlags
{
    DRAW_BACKGROUND = 1 << 0, /** Draw a background. Take the background into account when calculating the size. */
};

/**
 * @brief Font properties.
 */
typedef struct
{
    uint8_t  fg_color: 4;    /** Foreground color */
    uint8_t  bg_color: 4;    /** Background color */
    uint32_t fallback_glyph; /** Use the glyph for this codepoint for missing glyphs. */
    uint32_t flags;          /** Additional flags, reserved for future use */
} FontProperties;

/******************************************************************************/
/***        exported variables                                              ***/
/******************************************************************************/

/******************************************************************************/
/***        exported functions                                              ***/
/******************************************************************************/

/**
 * @brief Initialize the ePaper display
 */
void epd_init();

/**
 * @brief Enable display power supply.
 */
void epd_poweron();

/**
 * @brief Disable display power supply.
 */
void epd_poweroff();

/**
 * @brief Clear the whole screen by flashing it.
 */
void epd_clear();

void epd_poweroff_all();

/**
 * @brief Clear an area by flashing it.
 *
 * @param area The area to clear.
 */
void epd_clear_area(Rect_t area);

/**
 * @brief Clear an area by flashing it.
 *
 * @param area       The area to clear.
 * @param cycles     The number of black-to-white clear cycles.
 * @param cycle_time Length of a cycle. Default: 50 (us).
 */
void epd_clear_area_cycles(Rect_t area, int32_t cycles, int32_t cycle_time);

/**
 * @brief Darken / lighten an area for a given time.
 *
 * @param area  The area to darken / lighten.
 * @param time  The time in us to apply voltage to each pixel.
 * @param color 1: lighten, 0: darken.
 */
void epd_push_pixels(Rect_t area, int16_t time, int32_t color);

/**
 * @brief Draw a picture to a given area. The image area is not cleared and
 *        assumed to be white before drawing.
 *
 * @param area The display area to draw to. `width` and `height` of the area
 *             must correspond to the image dimensions in pixels.
 * @param data The image data, as a buffer of 4 bit wide brightness values.
 *             Pixel data is packed (two pixels per byte). A byte cannot wrap
 *             over multiple rows, images of uneven width must add a padding
 *             nibble per line.
 */
void IRAM_ATTR epd_draw_grayscale_image(Rect_t area, uint8_t *data);

/**
 * @brief Draw a picture to a given area, with some draw mode.
 *
 * @note The image area is not cleared before drawing. For example, this can be
 *       used for pixel-aligned clearing.
 *
 * @param area The display area to draw to. `width` and `height` of the area
 *             must correspond to the image dimensions in pixels.
 * @param data The image data, as a buffer of 4 bit wide brightness values.
 *             Pixel data is packed (two pixels per byte). A byte cannot wrap
 *             over multiple rows, images of uneven width must add a padding
 *             nibble per line.
 */
void IRAM_ATTR epd_draw_image(Rect_t area, uint8_t *data, DrawMode_t mode);

/**
 * @brief Rectancle representing the whole screen area.
 */
Rect_t epd_full_screen();


/**
 * @brief Draw a pixel a given framebuffer.
 *
 * @param x           Horizontal position in pixels.
 * @param y           Vertical position in pixels.
 * @param color       The gray value of the line (0-255);
 * @param framebuffer The framebuffer to draw to.
 */
void epd_draw_pixel(int32_t x, int32_t y, uint8_t color,
                    uint8_t *framebuffer);


#ifdef __cplusplus
}
#endif

#endif
/******************************************************************************/
/***        END OF FILE                                                     ***/
/******************************************************************************/