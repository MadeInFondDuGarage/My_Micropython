/**
 * @copyright Copyright (c) 2024  Shenzhen Xin Yuan Electronic Technology Co., Ltd
 * @date      2024-04-05
 * @note      Arduino Setting
 *            Tools ->
 *                  Board:"ESP32S3 Dev Module"
 *                  USB CDC On Boot:"Enable"
 *                  USB DFU On Boot:"Disable"
 *                  Flash Size : "16MB(128Mb)"
 *                  Flash Mode"QIO 80MHz
 *                  Partition Scheme:"16M Flash(3M APP/9.9MB FATFS)"
 *                  PSRAM:"OPI PSRAM"
 *                  Upload Mode:"UART0/Hardware CDC"
 *                  USB Mode:"Hardware CDC and JTAG"
 *  
 */

#include "HWCDC.h"
#include "WString.h"
#include <cstdio>
#ifndef BOARD_HAS_PSRAM
#error "Please enable PSRAM, Arduino IDE -> tools -> PSRAM -> OPI !!!"
#endif

/* Simple firmware for a ESP32 displaying a static image on an EPaper Screen.
 *
 * Write an image into a header file using a 3...2...1...0 format per pixel,
 * for 4 bits color (16 colors - well, greys.) MSB first.  At 80 MHz, screen
 * clears execute in 1.075 seconds and images are drawn in 1.531 seconds.
 */

#include <Arduino.h>
#include "epd_driver.h"
#include "pic3.h"
#include "pic1.h"

uint8_t *grayscale_img;
uint8_t *grayscale_img2;
uint8_t *MyPic;

#define _swap_int(a, b) \
    {                   \
        int32_t t = a;      \
        a = b;          \
        b = t;          \
    }

void epd_write_line(int32_t x0, int32_t y0, int32_t x1, int32_t y1, uint8_t color, uint8_t *framebuffer)
{
    int32_t steep = abs(y1 - y0) > abs(x1 - x0);
    if (steep)
    {
        _swap_int(x0, y0);
        _swap_int(x1, y1);
    }

    if (x0 > x1)
    {
        _swap_int(x0, x1);
        _swap_int(y0, y1);
    }

    int32_t dx, dy;
    dx = x1 - x0;
    dy = abs(y1 - y0);

    int32_t err = dx / 2;
    int32_t ystep;

    if (y0 < y1)
    {
        ystep = 1;
    }
    else
    {
        ystep = -1;
    }

    for (; x0 <= x1; x0++)
    {
        if (steep)
        {
            epd_draw_pixel(y0, x0, color, framebuffer);
        }
        else
        {
            epd_draw_pixel(x0, y0, color, framebuffer);
        }
        err -= dy;
        if (err < 0)
        {
            y0 += ystep;
            err += dx;
        }
    }
}


void setup()
{
    Serial.begin(115200);

    epd_init();

    // copy the image data to SRAM for faster display time
    grayscale_img = (uint8_t *)heap_caps_malloc(EPD_WIDTH * EPD_HEIGHT / 2, MALLOC_CAP_SPIRAM);
    MyPic = (uint8_t *)heap_caps_malloc(EPD_WIDTH * EPD_HEIGHT / 2, MALLOC_CAP_SPIRAM);
    if (grayscale_img == NULL) {
        Serial.println( "Could not allocate framebuffer in PSRAM!");
    }

    uint8_t grayscale_line[EPD_WIDTH / 2];
    uint8_t value = 0;
    for (uint32_t i = 0; i < EPD_WIDTH / 2; i++) {
        uint8_t segment = i / (EPD_WIDTH / 16 / 2);
        grayscale_line[i] = (segment << 4) | segment;
    }
    for (uint32_t y = 0; y < EPD_HEIGHT; y++) {
        memcpy(grayscale_img + EPD_WIDTH / 2 * y, grayscale_line, EPD_WIDTH / 2);
    }


}

void loop()
{   
    


    epd_poweron();
    epd_clear_area_cycles({.x = 0, .y = 0, .width = EPD_WIDTH, .height = EPD_HEIGHT}, 1, 100);
    epd_draw_image({.x = 0, .y = 0, .width = EPD_WIDTH, .height = EPD_HEIGHT}, grayscale_img, BLACK_ON_WHITE);
    epd_poweroff();
    delay(3000);
    epd_poweron();
    epd_clear_area_cycles({.x = 0, .y = 0, .width = EPD_WIDTH, .height = EPD_HEIGHT}, 1, 100);
    epd_write_line(10,10,20,20,255,MyPic);
    epd_poweroff();
    delay(3000);
    epd_poweron();
    epd_clear_area_cycles({.x = 0, .y = 0, .width = EPD_WIDTH, .height = EPD_HEIGHT}, 1, 100);
   Rect_t area2 = {
        .x = 0,
        .y = 0,
        .width = pic3_width,
        .height = pic3_height
    };
    epd_draw_image(area2, (uint8_t *)pic3_data, BLACK_ON_WHITE);
    epd_poweroff();
    delay(3000);
        epd_poweron();
    epd_clear();
    area2 = {
        .x = 100,
        .y = 10,
        .width = pic1_width,
        .height = pic1_height
    };
    epd_draw_image(area2, (uint8_t *)pic1_data, BLACK_ON_WHITE);
    delay(3000);
    epd_clear_area_cycles({.x = 0, .y = 0, .width = EPD_WIDTH, .height = EPD_HEIGHT}, 1, 100);
    epd_poweroff();
    delay(3000);
    


}
