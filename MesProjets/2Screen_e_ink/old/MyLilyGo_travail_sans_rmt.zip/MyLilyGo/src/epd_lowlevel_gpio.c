/******************************************************************************/
/***        include files                                                   ***/
/******************************************************************************/



#include <rom/ets_sys.h> //natif interne
#include <driver/gpio.h>
#include "ed047tc1.h"

#include <xtensa/core-macros.h>



/******************************************************************************/
/***        local variables                                                 ***/
/******************************************************************************/

#define GPIO_SET(pin) ((pin) < 32 ? (REG_WRITE(GPIO_OUT_W1TS_REG, 1UL<<(pin))) : (REG_WRITE(GPIO_OUT1_W1TS_REG, 1UL<<((pin)-32))))
#define GPIO_CLR(pin) ((pin) < 32 ? (REG_WRITE(GPIO_OUT_W1TC_REG, 1UL<<(pin))) : (REG_WRITE(GPIO_OUT1_W1TC_REG, 1UL<<((pin)-32))))

#define TICKS_PER_100NS 24  // 240MHz CPU

/******************************************************************************/
/***        exported functions                                              ***/
/******************************************************************************/

void pulse_init(gpio_num_t pin)
{
    gpio_set_direction(pin, GPIO_MODE_OUTPUT);
    gpio_set_level(pin, 0);
}


void IRAM_ATTR pulse_ckv_ticks(uint16_t high_ticks, uint16_t low_ticks, bool wait)
{
    uint32_t high_cycles = high_ticks * TICKS_PER_100NS;
    uint32_t low_cycles  = low_ticks  * TICKS_PER_100NS;
    volatile uint32_t end;

    if (high_ticks > 0)
    {
        GPIO_SET(CKV);
        end = XTHAL_GET_CCOUNT() + high_cycles;
        while (XTHAL_GET_CCOUNT() < end);
        GPIO_CLR(CKV);
        if (wait && low_ticks)
        {
            end = XTHAL_GET_CCOUNT() + low_cycles;
            while (XTHAL_GET_CCOUNT() < end);
        }
    }
    else
    {
        GPIO_SET(CKV);
        end = XTHAL_GET_CCOUNT() + low_cycles;
        while (XTHAL_GET_CCOUNT() < end);
        GPIO_CLR(CKV);
        // pas de wait sur ce cas, phase LOW déjà consommée
    }
}

void IRAM_ATTR pulse_ckv_us(uint16_t high_us, uint16_t low_us, bool wait)
{
    pulse_ckv_ticks(high_us * 10, low_us * 10, wait);
}

/*void IRAM_ATTR pulse_ckv_ticks(uint16_t high_ticks, uint16_t low_ticks)
{
    if (high_ticks > 0)
    {
        GPIO_SET(CKV);
        ets_delay_us(high_ticks / 10);
        GPIO_CLR(CKV);
        // pas d'attente sur le low, comme wait=false
    }
    else
    {
        GPIO_SET(CKV);
        ets_delay_us(low_ticks / 10);
        GPIO_CLR(CKV);
    }
}*/

/*void IRAM_ATTR pulse_ckv_ticks(uint16_t high_ticks, uint16_t low_ticks)
{
    if (high_ticks > 0)
    {
        gpio_set_level(CKV, 1);
        ets_delay_us(high_ticks / 10);
        gpio_set_level(CKV, 0);
        if (low_ticks) ets_delay_us(low_ticks / 10);
    }
    else
    {
        gpio_set_level(CKV, 1);
        ets_delay_us(low_ticks / 10);
        gpio_set_level(CKV, 0);
    }
}*/

/*void IRAM_ATTR pulse_ckv_ticks(uint16_t high_ticks, uint16_t low_ticks)
{
    if (high_ticks > 0)
    {
        GPIO_SET(CKV);
        ets_delay_us(high_ticks / 10);
        GPIO_CLR(CKV);
        if (low_ticks) ets_delay_us(low_ticks / 10);
    }
    else
    {
        GPIO_SET(CKV);
        ets_delay_us(low_ticks / 10);
        GPIO_CLR(CKV);
    }
}*/

/*void IRAM_ATTR pulse_ckv_us(uint16_t high_us, uint16_t low_us)
{
    pulse_ckv_ticks(high_us * 10, low_us * 10);
}*/

/******************************************************************************/
/***        END OF FILE                                                     ***/
/******************************************************************************/