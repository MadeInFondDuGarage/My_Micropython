/**
 * Emit a pulse of precise length on a pin, using the RMT peripheral.
 */

#ifndef _EPD_LOWLEVEL_GPIO_H_
#define _EPD_LOWLEVEL_GPIO_H_

#ifdef __cplusplus
extern "C" {
#endif

/******************************************************************************/
/***        include files                                                   ***/
/******************************************************************************/

#include <stdint.h>

#include <esp_rom_sys.h> //natif interne
#include <driver/gpio.h>

/******************************************************************************/
/***        macro definitions                                               ***/
/******************************************************************************/

/******************************************************************************/
/***        type definitions                                                ***/
/******************************************************************************/

/******************************************************************************/
/***        exported variables                                              ***/
/******************************************************************************/

/******************************************************************************/
/***        exported functions                                              ***/
/******************************************************************************/

/**
 * @brief Initializes RMT Channel 0 with a pin for RMT pulsing.
 *
 * @note The pin will have to be re-initialized if subsequently used as GPIO.
 */
void pulse_init(gpio_num_t pin);

/**
 * @brief Outputs a single pulse (high -> low) on the configured pin.
 *
 * @note This function will always wait for a previous call to finish.
 *
 * @param high_time_us Pulse high time in us.
 * @param low_time_us  Pulse low time in us.
 */
void IRAM_ATTR pulse_ckv_ticks(uint16_t high_ticks, uint16_t low_ticks, bool wait);


/**
 * @brief Outputs a single pulse (high -> low) on the configured pin.
 *
 * @note This function will always wait for a previous call to finish.
 *
 * @param high_time_us Pulse high time clock ticks.
 * @param low_time_us  Pulse low time in clock ticks.
 * 
 */
void IRAM_ATTR pulse_ckv_us(uint16_t high_us, uint16_t low_us, bool wait);

#ifdef __cplusplus
}
#endif

#endif
/******************************************************************************/
/***        END OF FILE                                                     ***/
/******************************************************************************/