//
// Based on https://github.com/russhughes/lilygo_t547
// Patched for ESP32-S3 + LilyGo-EPD47 driver (https://github.com/Xinyuan-LilyGO/LilyGo-EPD47/tree/esp32s3)
// - Removed epd_highlevel / epd_internals dependencies
// - Removed rotation support (fixed landscape)
// - Removed back_fb / difference_fb / dirty_lines / waveform / lut
// - Fixed mp_obj_type_t API for MicroPython >= 1.20
// - Fixed mp_raise_ValueError API for MicroPython >= 1.20
// - EpdRect -> Rect_t
// - epd_draw_rect / epd_fill_rect signature updated
// - epd_fullclear -> epd_clear
// - epd_hl_update_area -> epd_draw_grayscale_image
//

#include <string.h>
#include <math.h>
#include "py/runtime.h"
#include "py/objstr.h"

#include "epd_driver.h"
#include "t547.h"
#include "pic1.h"

//
// Method Implementations
//
extern const mp_obj_type_t t547_type;


// init()
static mp_obj_t t547_init(size_t n_args, const mp_obj_t *args) {
    epd_init();
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_init_obj, 1, 2, t547_init);

// deinit()
static mp_obj_t t547_deinit(mp_obj_t self_in) {
    epd_poweroff_all();
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_1(t547_deinit_obj, t547_deinit);

// power(state)
static mp_obj_t t547_power(mp_obj_t self_in, mp_obj_t state) {
    if (mp_obj_is_true(state)) {
        epd_poweron();
    } else {
        epd_poweroff();
    }
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_2(t547_power_obj, t547_power);

// width() - fixed landscape
static mp_obj_t t547_width(mp_obj_t self_in) {
    return mp_obj_new_int(EPD_WIDTH);
}
static MP_DEFINE_CONST_FUN_OBJ_1(t547_width_obj, t547_width);

// height() - fixed landscape
static mp_obj_t t547_height(mp_obj_t self_in) {
    return mp_obj_new_int(EPD_HEIGHT);
}
static MP_DEFINE_CONST_FUN_OBJ_1(t547_height_obj, t547_height);

// push(time, color)
static mp_obj_t t547_push(size_t n_args, const mp_obj_t *args) {
    int time  = mp_obj_get_int(args[1]);
    int color = mp_obj_get_int(args[2]);
    epd_push_pixels(epd_full_screen(), time, color);
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_push_obj, 1, 3, t547_push);

// clear()
static mp_obj_t t547_clear(size_t n_args, const mp_obj_t *args) {
    epd_clear();
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_clear_obj, 1, 7, t547_clear);

// show([x, y, w, h])
// draw_mode parameter kept for API compatibility but ignored
// epd_draw_grayscale_image does not support partial modes
static mp_obj_t t547_show(size_t n_args, const mp_obj_t *args) {
    t547_obj_t *self = MP_OBJ_TO_PTR(args[0]);
	int8_t retour;
	retour=0;
	Rect_t area = {0, 0, EPD_WIDTH, EPD_HEIGHT};
    if (n_args == 1) {
		epd_draw_grayscale_image(area, self->front_fb);
		retour=1;
    }
    if (n_args == 5) {
		area = (Rect_t){mp_obj_get_int(args[1]), mp_obj_get_int(args[2]),mp_obj_get_int(args[3]),mp_obj_get_int(args[4])};
		epd_draw_grayscale_image(area, self->front_fb);
		retour=2;
    }
	if (n_args>1 && n_args<5){
		area = (Rect_t){0,0,pic1_width,pic1_height};
		epd_draw_image(area, (uint8_t *)pic1_data, BLACK_ON_WHITE);
		retour=10;
	}
    return mp_obj_new_int(retour);
}
static MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_show_obj, 1, 6, t547_show);


void epd_draw_pixel(int32_t x, int32_t y, uint8_t color, uint8_t *framebuffer)
{
    if (x < 0 || x >= EPD_WIDTH)
    {
        return;
    }
    if (y < 0 || y >= EPD_HEIGHT)
    {
        return;
    }
    uint8_t *buf_ptr = &framebuffer[y * EPD_WIDTH / 2 + x / 2];
    if (x % 2)
    {
        *buf_ptr = (*buf_ptr & 0x0F) | (color & 0xF0);
    }
    else
    {
        *buf_ptr = (*buf_ptr & 0xF0) | (color >> 4);
    }
}

// pixel(x, y, color)
static mp_obj_t t547_pixel(size_t n_args, const mp_obj_t *args) {
    t547_obj_t *self = MP_OBJ_TO_PTR(args[0]);
    int x     = mp_obj_get_int(args[1]);
    int y     = mp_obj_get_int(args[2]);
    int color = mp_obj_get_int(args[3]);
    epd_draw_pixel(x, y, color, self->front_fb);
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_pixel_obj, 4, 4, t547_pixel);

void epd_copy_to_framebuffer(Rect_t image_area, uint8_t *image_data,
                             uint8_t *framebuffer)
{
    assert(image_data != NULL || framebuffer != NULL);

    for (uint32_t i = 0; i < image_area.width * image_area.height; i++)
    {
        uint32_t value_index = i;
        // for images of uneven width,
        // consume an additional nibble per row.
        if (image_area.width % 2)
        {
            value_index += i / image_area.width;
        }
        uint8_t val = (value_index % 2) ? (image_data[value_index / 2] & 0xF0) >> 4
                                        : image_data[value_index / 2] & 0x0F;

        int32_t xx = image_area.x + i % image_area.width;
        if (xx < 0 || xx >= EPD_WIDTH)
        {
            continue;
        }
        int32_t yy = image_area.y + i / image_area.width;
        if (yy < 0 || yy >= EPD_HEIGHT)
        {
            continue;
        }
        uint8_t *buf_ptr = &framebuffer[yy * EPD_WIDTH / 2 + xx / 2];
        if (xx % 2)
        {
            *buf_ptr = (*buf_ptr & 0x0F) | (val << 4);
        }
        else
        {
            *buf_ptr = (*buf_ptr & 0xF0) | val;
        }
    }
}

// copy_bitmap(bitmap, x, y, width, height)
static mp_obj_t t547_copy_bitmap(size_t n_args, const mp_obj_t *args) {
    t547_obj_t *self = MP_OBJ_TO_PTR(args[0]);

    mp_buffer_info_t bitmap_info;
    mp_get_buffer_raise(args[1], &bitmap_info, MP_BUFFER_READ);

    Rect_t area = {
        .x      = mp_obj_get_int(args[2]),
        .y      = mp_obj_get_int(args[3]),
        .width  = mp_obj_get_int(args[4]),
        .height = mp_obj_get_int(args[5]),
    };

    epd_copy_to_framebuffer(area, bitmap_info.buf, self->front_fb);
    return mp_const_none;
}
static MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(t547_copy_bitmap_obj, 6, 6, t547_copy_bitmap);

//
// Module
//

static const mp_rom_map_elem_t t547_locals_dict_table[] = {
    {MP_ROM_QSTR(MP_QSTR_init),          MP_ROM_PTR(&t547_init_obj)},
    {MP_ROM_QSTR(MP_QSTR_deinit),        MP_ROM_PTR(&t547_deinit_obj)},
    {MP_ROM_QSTR(MP_QSTR_power),         MP_ROM_PTR(&t547_power_obj)},
    {MP_ROM_QSTR(MP_QSTR_width),         MP_ROM_PTR(&t547_width_obj)},
    {MP_ROM_QSTR(MP_QSTR_height),        MP_ROM_PTR(&t547_height_obj)},
    {MP_ROM_QSTR(MP_QSTR_push),          MP_ROM_PTR(&t547_push_obj)},
    {MP_ROM_QSTR(MP_QSTR_clear),         MP_ROM_PTR(&t547_clear_obj)},
    {MP_ROM_QSTR(MP_QSTR_show),          MP_ROM_PTR(&t547_show_obj)},
    {MP_ROM_QSTR(MP_QSTR_pixel),         MP_ROM_PTR(&t547_pixel_obj)},
    {MP_ROM_QSTR(MP_QSTR_copy_bitmap),   MP_ROM_PTR(&t547_copy_bitmap_obj)},
    {MP_ROM_QSTR(MP_QSTR_TRANSPARENT),   MP_ROM_INT(-1)},
};
static MP_DEFINE_CONST_DICT(t547_locals_dict, t547_locals_dict_table);

static void t547_print(const mp_print_t *print, mp_obj_t self_in, mp_print_kind_t kind) {
    (void) kind;
    mp_printf(print, "<t547>");
}

mp_obj_t t547_make_new(const mp_obj_type_t *type, size_t n_args, size_t n_kw, const mp_obj_t *all_args) {
    mp_arg_check_num(n_args, n_kw, 0, 0, false);

    const int fb_size = EPD_WIDTH / 2 * EPD_HEIGHT;
    t547_obj_t *self  = m_new_obj(t547_obj_t);
    self->base.type   = &t547_type;
    self->front_fb    = m_malloc(fb_size);

    if (self->front_fb == NULL)
        mp_raise_msg(&mp_type_MemoryError, MP_ERROR_TEXT("out of memory"));

    memset(self->front_fb, 0xFF, fb_size);
    return MP_OBJ_FROM_PTR(self);
}

MP_DEFINE_CONST_OBJ_TYPE(
    t547_type,
    MP_QSTR_t547,
    MP_TYPE_FLAG_NONE,
    print, t547_print,
    make_new, t547_make_new,
    locals_dict, &t547_locals_dict
);

static const mp_rom_map_elem_t t547_module_globals_table[] = {
    {MP_ROM_QSTR(MP_QSTR___name__), MP_ROM_QSTR(MP_QSTR_t547)},
    {MP_ROM_QSTR(MP_QSTR_T547),     (mp_obj_t) &t547_type},
};
static MP_DEFINE_CONST_DICT(t547_module_globals, t547_module_globals_table);

const mp_obj_module_t t547_user_cmodule = {
    .base    = {&mp_type_module},
    .globals = (mp_obj_dict_t *) &t547_module_globals,
};

MP_REGISTER_MODULE(MP_QSTR_t547, t547_user_cmodule);
