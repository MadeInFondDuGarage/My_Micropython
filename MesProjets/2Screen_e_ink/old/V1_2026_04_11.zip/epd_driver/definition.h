/******************************************************************************/
/***        include files                                                   ***/
/******************************************************************************/

/******************************************************************************/
/***        pin definitions                                               ***/
/******************************************************************************/

/* Config Reggister Control */
#define CFG_DATA GPIO_NUM_13
#define CFG_CLK GPIO_NUM_12
#define CFG_STR GPIO_NUM_0

/* Control Lines */
#define CKV GPIO_NUM_38
#define STH GPIO_NUM_40

/* Edges */
#define CKH GPIO_NUM_41

/* Data Lines */
#define D7 GPIO_NUM_7
#define D6 GPIO_NUM_6
#define D5 GPIO_NUM_5
#define D4 GPIO_NUM_4
#define D3 GPIO_NUM_3
#define D2 GPIO_NUM_2
#define D1 GPIO_NUM_1
#define D0 GPIO_NUM_8

/******************************************************************************/
/***        screen definitions                                               ***/
/******************************************************************************/
/**
 * @brief Width of the display area in pixels.
 */
#define EPD_WIDTH 960

/**
 * @brief Height of the display area in pixels.
 */
#define EPD_HEIGHT 540

/*
 * @brief number of bytes needed for one line of EPD pixel data.
 */

#define EPD_LINE_BYTES EPD_WIDTH / 4
// EPD_ROW_BUFFER_SIZE = EPD_WIDTH / 4 = 240 bytes, EPD_WIDTH / 4 + 8 bytes de padding pour l'alignement DMA.
#define EPD_ROW_BUFFER_SIZE (EPD_WIDTH / 4 + 8)

/*00 = no-op
01 = noir
10 = blanc
11 = no-op*/
//sur un octet donc 2 pixels
#define CLEAR_BYTE 0B10101010
#define DARK_BYTE 0B01010101

